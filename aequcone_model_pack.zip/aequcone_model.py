#!/usr/bin/env python3
"""
AEQUCONE concept-stage parametric model  (reproducible, stdlib + numpy)
Purpose : quantify cone-vs-alternatives, foundation demand, kit-of-parts sizing, uncertainty.
Status  : CONCEPT STAGE. Not a stamped structural design. Every coefficient flagged [ASSUMED]
          is a gate item (see blueprint section 9) until wind-tunnel/CFD + site geotech replace it.
Units   : SI (m, kN, kPa, kg). Design wind = 250 mph 3-s gust (ICC 500 / FEMA P-361 basis).
"""
import json, math
import numpy as np

rng = np.random.default_rng(20261009)
MPH = 0.44704
V250 = 250 * MPH          # 111.76 m/s
G = 9.81
HEAD = 2.1                # m clear headroom counted as "usable floor"
AU = 40.0                 # m2 usable floor used for equal-function shape comparison
GCPI = 0.55               # ICC 500 tornado shelter internal pressure coeff (partially enclosed)
SIGMA = 200.0             # kg/m2 shell areal mass, tier-neutral comparison basis [ASSUMED]
OUT = {}

# ---------------------------------------------------------------- wind -----
EXPO = {'B': (7.0, 365.76), 'C': (9.5, 274.32), 'D': (11.5, 213.36)}   # ASCE 7 alpha, zg
def Kz(z, ex='C'):
    a, zg = EXPO[ex]
    return 2.01 * (np.clip(z, 4.57, zg) / zg) ** (2.0 / a)
def qz(z, V=V250, ex='C'):
    return 0.613 * Kz(z, ex) * V ** 2          # N/m2, Kd=Kzt=Ke=1

def integrate(width, H, Cf, V=V250, ex='C', n=600):
    z = np.linspace(0, H, n + 1); zm = 0.5 * (z[1:] + z[:-1]); dz = z[1] - z[0]
    dF = qz(zm, V, ex) * Cf * width(zm) * dz / 1000.0     # kN
    F = dF.sum(); M = (dF * zm).sum()
    return F, M, (M / F if F > 0 else 0)

# -------------------------------------------------------------- shapes -----
def box(h=2.7):
    a = math.sqrt(AU)
    return dict(name='Box+flat roof', R=a/2, lever=a/2, H=h, Ap=a*a, S=4*a*h + a*a,
                width=lambda z: np.full_like(z, a), Cf=1.41, CL=0.70, impact=1.0, fab=1.0,
                memb=0.4, edgefree=0.0)
def cyl(h=2.7):
    R = math.sqrt(AU/math.pi)
    return dict(name='Drum+flat roof', R=R, lever=R, H=h, Ap=math.pi*R*R, S=2*math.pi*R*h + math.pi*R*R,
                width=lambda z: np.full_like(z, 2*R), Cf=0.60, CL=0.70, impact=2/3, fab=0.9,
                memb=0.6, edgefree=0.3)
def dome():
    R = math.sqrt(AU/math.pi + HEAD**2)
    return dict(name='Hemisphere dome', R=R, lever=R, H=R, Ap=math.pi*R*R, S=2*math.pi*R*R,
                width=lambda z: 2*np.sqrt(np.maximum(R*R - z*z, 0)), Cf=0.35, CL=0.50, impact=0.5,
                fab=0.5, memb=1.0, edgefree=1.0)
def cone(alpha_deg, hk=0.0):
    a = math.radians(alpha_deg)
    R = math.sqrt(AU/math.pi) + max(0.0, HEAD - hk) / math.tan(a)
    Hc = R * math.tan(a); H = hk + Hc
    def width(z):
        return np.where(z < hk, 2*R, 2*R*np.clip(1 - (z - hk)/Hc, 0, 1))
    fa_knee, fa_cone = 2*R*hk, R*Hc
    imp = (fa_knee*(2/3) + fa_cone*(2/3)*math.sin(a)**2) / (fa_knee + fa_cone)
    nm = f'Cone {alpha_deg:.0f}deg' + (f' + {hk:.1f}m knee' if hk > 0 else '')
    return dict(name=nm, R=R, lever=R, H=H, Ap=math.pi*R*R, S=2*math.pi*R*hk + math.pi*R*R/math.cos(a),
                width=width, Cf=0.60, CL=0.25, impact=imp, fab=1.0, memb=0.9,
                edgefree=1.0 if hk == 0 else 0.7, alpha=alpha_deg, hk=hk)

def metrics(s, V=V250, ex='C', Cf=None, CL=None, sigma=SIGMA):
    Cf = s['Cf'] if Cf is None else Cf; CL = s['CL'] if CL is None else CL
    F, M, zcp = integrate(s['width'], s['H'], Cf, V, ex)
    q_roof = float(qz(s['H'], V, ex))
    U = q_roof * (CL + GCPI) * s['Ap'] / 1000.0
    Ws = sigma * G * s['S'] / 1000.0
    HD = max(0.0, U + M/s['lever'] - 0.9*Ws)
    return dict(F=F, M=M, zcp=zcp, U=U, Ws=Ws, HD=HD, H=s['H'], R=s['R'], S=s['S'])

# ============================================================= A. shapes =====
cands = [box(), cyl(), dome(), cone(60), cone(60, 1.5), cone(45, 2.1)]
rows = []
for s in cands:
    m = metrics(s)
    rows.append(dict(name=s['name'], D=2*s['R'], H=m['H'], S_per_Au=s['S']/AU, F=m['F'], M=m['M'], U=m['U'],
                     Ws=m['Ws'], HD=m['HD'], M_per_Au=m['M']/AU, HD_per_Au=m['HD']/AU,
                     impact=s['impact'], fab=s['fab'], memb=s['memb'], edgefree=s['edgefree']))
OUT['shape_table'] = rows

# analytic sanity check: same D, H cone vs cylinder (uniform q gives 1/2 and 1/3)
R0, H0 = 4.0, 6.0
Fc, Mc, _ = integrate(lambda z: np.full_like(z, 2*R0), H0, 0.6)
Fk, Mk, _ = integrate(lambda z: 2*R0*(1 - z/H0), H0, 0.6)
Fu = lambda z: 1.0
OUT['cone_vs_cyl_same_D_H'] = dict(F_ratio=Fk/Fc, M_ratio=Mk/Mc, uniform_q_F=0.5, uniform_q_M=1/3)

# MCDA with weight sensitivity (Pareto + random-weight win frequency)
crit = ['M_per_Au', 'HD_per_Au', 'S_per_Au', 'impact', 'fab', 'memb', 'edgefree']
lower_better = {'M_per_Au', 'HD_per_Au', 'S_per_Au', 'impact'}
X = np.array([[r[c] for c in crit] for r in rows], float)
N = np.zeros_like(X)
for j, c in enumerate(crit):
    lo, hi = X[:, j].min(), X[:, j].max()
    N[:, j] = (X[:, j] - lo) / (hi - lo) if hi > lo else 1.0
    if c in lower_better: N[:, j] = 1 - N[:, j]
def wins(alpha):
    cnt = np.zeros(len(rows))
    for _ in range(20000):
        w = rng.dirichlet(alpha); cnt[np.argmax(N @ w)] += 1
    return (cnt / cnt.sum()).tolist()
OUT['mcda_names'] = [r['name'] for r in rows]
OUT['mcda_win_uniform'] = wins(np.ones(len(crit)))
OUT['mcda_win_safety'] = wins(np.array([2, 3, 1, 2, 1, 1, 2], float))     # safety-weighted prior
dom = []
for i in range(len(rows)):
    for j in range(len(rows)):
        if i != j and np.all(N[j] >= N[i]) and np.any(N[j] > N[i]): dom.append((rows[i]['name'], rows[j]['name']))
OUT['pareto_dominated'] = dom

# cone family sweep (equal usable area)
sweep = []
for a in [40, 45, 50, 55, 60, 65, 70, 75]:
    for hk in [0.0, 0.9, 1.5, 2.1]:
        s = cone(a, hk); m = metrics(s)
        sweep.append(dict(alpha=a, hk=hk, D=2*s['R'], H=m['H'], S_per_Au=s['S']/AU, M=m['M'], U=m['U'],
                          HD=m['HD'], HD_per_Au=m['HD']/AU, impact=s['impact']))
OUT['cone_sweep'] = sweep


# ================================================ B. frustum family + kit of parts ====
L = 2.0                       # constant chord (m): ONE segment geometry for every size
ALPHA, HK = 45.0, 2.1         # nominal shell: 45deg conical roof on a 2.1 m knee wall (all floor usable)
TAU = {8: 0.0, 12: 0.0, 16: 0.0, 24: 0.3, 36: 0.5, 48: 0.6}      # truncation ratio r_top/R (vented lantern)
WIND = {'WC1': 45.0, 'WC2': 60.0, 'WC3': 80.0, 'WC4': V250}      # 3-s gust design speeds, m/s
KT = 23.0                     # 1/m uplift torque factor, conservative end of published 23-33 (tension)
PHI_ASD = 1.2                 # Qult >= 1.2 x ultimate-level demand  (== ASD FS 2.0 with 0.6W)
GAMMA_S, PHI_S = 18.0, 32.0   # generic dense granular soil [ASSUMED - replace with site geotech]
KP = math.tan(math.radians(45 + PHI_S/2))**2

def rhs(h, b, t):
    Zp = b*h**2/4 - (b - 2*t)*(h - 2*t)**2/4                     # mm3
    A = 2*(h + b)*t - 4*t*t                                       # mm2 (square corners)
    return 275.0*Zp/1e6, A*7.85e-3                                # Mp kN.m, kg/m
SECTIONS = [(f'RHS {h}x{b}x{t}',) + rhs(h, b, t) for h, b, t in [(150,100,6),(200,100,8),(250,150,10),(300,200,12),(400,200,16)]]
ANCHORS = [(60, 20), (100, 28), (150, 40), (250, 62), (400, 95), (650, 150)]   # Qult kN, kg [ASSUMED indicative]

def frustum(R, alpha=ALPHA, hk=HK, tau=0.0, CLc=0.25, CLflat=0.70):
    a = math.radians(alpha); rt = tau*R; Hc = (R - rt)*math.tan(a); H = hk + Hc
    def width(z):
        return np.where(z < hk, 2*R, 2*(R - np.clip(z - hk, 0, Hc)/math.tan(a)))
    slant = (R - rt)/math.cos(a)
    S = 2*math.pi*R*hk + math.pi*(R + rt)*slant + math.pi*rt*rt
    return dict(R=R, lever=R, H=H, Ap=math.pi*R*R, S=S, width=width, Cf=0.60,
                CL=CLc*(1 - tau**2) + CLflat*tau**2, tau=tau)

def metrics(s, V=V250, ex='C', Cf=None, CL=None, sigma=SIGMA, gcpi=GCPI):
    Cf = s['Cf'] if Cf is None else Cf; CL = s['CL'] if CL is None else CL
    F, M, zcp = integrate(s['width'], s['H'], Cf, V, ex)
    U = float(qz(s['H'], V, ex)) * (CL + gcpi) * s['Ap'] / 1000.0
    Ws = sigma*G*s['S']/1000.0
    return dict(F=F, M=M, zcp=zcp, U=U, Ws=Ws, HD=max(0.0, U + M/s['lever'] - 0.9*Ws), H=s['H'], R=s['R'], S=s['S'])

def design_foundation(n, V, alpha=ALPHA, hk=HK, tau=None, sigma=SIGMA, gcpi=GCPI, chord=L, per_node=1, hub=False):
    R = chord/(2*math.sin(math.pi/n)); tau = TAU.get(n, 0.0) if tau is None else tau
    sh = frustum(R, alpha, hk, tau); m = metrics(sh, V=V, sigma=sigma, gcpi=gcpi)
    Wring = n*100*G/1000.0
    P = 0.9*(m['Ws'] + Wring) - m['U']
    Tmax = max(0.0, (2*m['M']/R - P)/n); Nmax = max(0.0, (P + 2*m['M']/R)/n)
    Qreq = PHI_ASD*Tmax/per_node
    cls = next((a for a in ANCHORS if a[0] >= Qreq), None)
    na = per_node
    if cls is None: cls = ANCHORS[-1]; na = per_node*math.ceil(Qreq/cls[0])
    Mseg = max(Tmax, Nmax)*chord/8.0
    sec = next((s_ for s_ in SECTIONS if 0.9*s_[1] >= Mseg), SECTIONS[-1])
    d = min(1.5, max(0.3, math.sqrt(max(0.0, 2*m['F']/(GAMMA_S*KP*(2*R)*0.5)))))
    skirt_kg = 0.004*chord*d*7850*1.15
    seg_kg = sec[2]*chord + 12.0
    hub_kg = (n//2)*R*22.4 if hub else 0.0
    steel_kg = n*(seg_kg + na*cls[1] + skirt_kg + 5.0) + hub_kg
    t_install_h = n*(0.33*na + 0.17) + 2.0
    return dict(n=n, D=2*R, Afloor=math.pi*R*R, H=sh['H'], tau=tau, F=m['F'], M=m['M'], U=m['U'], Ws=m['Ws'], HD=m['HD'],
                P=P, Tmax=Tmax, Nmax=Nmax, Qreq=Qreq, anchor_Q=cls[0], anchors_per_node=na, torque=cls[0]/KT,
                section=sec[0], Mseg=Mseg, skirt=d, steel_t=steel_kg/1000.0, seg_kg=seg_kg, t_install_h=t_install_h,
                Qmargin=cls[0]*na*per_node/ (per_node*max(Qreq*per_node,1e-9)) if Qreq > 0 else None)

kit = []
for n in TAU:
    for wc, V in WIND.items():
        d = design_foundation(n, V); d['wc'] = wc; d['V'] = V; kit.append(d)
OUT['kit_table'] = kit
ref = next(r for r in kit if r['n'] == 12 and r['wc'] == 'WC4')
OUT['ref'] = ref

# ================================== C. gravity raft vs anchored ring (reference unit) ====
def gravity_raft(n=12, V=V250):
    R = L/(2*math.sin(math.pi/n)); sh = frustum(R, tau=TAU[n]); m = metrics(sh, V=V)
    Rf = R + 0.4; mu = 0.5
    Wreq = (m['U'] + max(m['M']/Rf, m['F']/mu))/0.9
    Wf = max(0.0, Wreq - m['Ws']); Vc = max(Wf/24.0, 0.25*math.pi*Rf*Rf)
    co2 = Vc*(2400*0.13 + 80*1.2)/1000.0                    # tCO2e  [ASSUMED indicative factors]
    return dict(R=R, Rf=Rf, Wreq=Wreq, Wf=Wf, Vc=Vc, thick=Vc/(math.pi*Rf*Rf), mass_t=Vc*2.4, co2_t=co2,
                bearing_kPa=(m['Ws'] + Vc*24.0)/(math.pi*Rf*Rf))
gr = gravity_raft(); OUT['gravity_ref'] = gr
kit_co2_rec, kit_co2_virgin = ref['steel_t']*0.6, ref['steel_t']*1.9
OUT['gravity_vs_kit'] = dict(raft_mass_t=gr['mass_t'], kit_steel_t=ref['steel_t'], mass_ratio=ref['steel_t']/gr['mass_t'],
                             raft_co2=gr['co2_t'], kit_co2_recycled=kit_co2_rec, kit_co2_virgin=kit_co2_virgin,
                             co2_ratio_recycled=kit_co2_rec/gr['co2_t'], co2_ratio_virgin=kit_co2_virgin/gr['co2_t'])

# ======================================== D. flotation + berm (reference unit) ====
flo = []
rc, dc, tw = 1.5, 2.4, 0.15
Wcell = (math.pi*(rc + tw)**2*0.2 + 2*math.pi*rc*dc*tw)*24.0      # kN: base slab + wall, concrete
for zw in [0.0, 0.5, 1.0, 1.5, 2.0, 3.0]:
    Vsub = math.pi*(rc + tw)**2*max(0.0, dc + 0.2 - zw); Fb = 9.81*Vsub
    flo.append(dict(water_depth=zw, buoyancy=Fb, weight=Wcell, margin=(Wcell/Fb if Fb > 0 else None)))
OUT['flotation'] = flo
Rr = ref['D']/2; Hh = ref['H']
berm = []
for hb in [0, 0.5, 1.0, 1.5, 2.0, 2.1, 3.0]:
    w = lambda z, hb=hb: np.where(z < hb, 0.0, frustum(Rr)['width'](z))
    F, M, _ = integrate(w, Hh, 0.6); berm.append(dict(berm_h=hb, F=F, M=M))
for b in berm: b['F_pct'] = 100*b['F']/berm[0]['F']; b['M_pct'] = 100*b['M']/berm[0]['M']
OUT['berm'] = berm

# ============================================================ E. Monte Carlo ====
R = ref['D']/2; Qcls = ref['anchor_Q']; Tinst = Qcls/KT
mc = []
for _ in range(20000):
    ex = rng.choice(['B', 'C', 'D'], p=[0.2, 0.6, 0.2])
    Cf = rng.uniform(0.5, 0.8); CLc = rng.uniform(0.05, 0.5)
    sig = SIGMA*rng.uniform(0.85, 1.15); kt = rng.uniform(15, 33); gci = rng.choice([0.18, 0.55], p=[0.15, 0.85])
    sh = frustum(R, CLc=CLc); sh['Cf'] = Cf
    F, M, _ = integrate(sh['width'], sh['H'], Cf, V250, ex, n=120)
    U = float(qz(sh['H'], V250, ex))*(sh['CL'] + gci)*sh['Ap']/1000.0
    Ws = sig*G*sh['S']/1000.0; P = 0.9*(Ws + 12*100*G/1000.0) - U
    T = max(0.0, (2*M/R - P)/12); Q = PHI_ASD*T
    mc.append((F, M, U, T, Q, Q/(kt*Tinst)))      # utilisation vs installed-torque capacity with TRUE Kt
mc = np.array(mc); pct = lambda x: [float(np.percentile(x, p)) for p in (5, 50, 95)]
h_u, b_u = np.histogram(np.clip(mc[:, 5], 0, 1.2), bins=24, range=(0, 1.2)); h_t, b_t = np.histogram(mc[:, 3], bins=24)
OUT['mc_hist'] = dict(util_counts=h_u.tolist(), util_edges=b_u.tolist(), T_counts=h_t.tolist(), T_edges=b_t.tolist())
OUT['mc'] = dict(F=pct(mc[:, 0]), M=pct(mc[:, 1]), U=pct(mc[:, 2]), Tmax=pct(mc[:, 3]), Qreq=pct(mc[:, 4]),
                 util=pct(mc[:, 5]), p_util_gt1=float((mc[:, 5] > 1).mean()), anchor_class=Qcls, torque=Tinst)

# ===================================================== F. iteration ledger + plateau attempts ====
steel = ref['steel_t']
led = [
 dict(it=0, name='Baseline: CIP gravity raft + conical shell', mass_t=gr['mass_t'], co2_t=gr['co2_t'], tooling=6, steps=9,
      days_to_load=10.0, margin=1.00, demount_pct=0),
 dict(it=1, name='Ring + screw anchors replace raft', mass_t=steel, co2_t=kit_co2_rec, tooling=6, steps=5, days_to_load=1.0,
      margin=1.00, demount_pct=90),
 dict(it=2, name='Constant-chord n-gon segment', mass_t=steel, co2_t=kit_co2_rec, tooling=1, steps=5, days_to_load=1.0,
      margin=1.00, demount_pct=90),
 dict(it=3, name='Skirt fin carries sliding (no extra anchors)', mass_t=steel, co2_t=kit_co2_rec, tooling=1, steps=5,
      days_to_load=1.0, margin=1.00, demount_pct=90),
 dict(it=4, name='Discrete anchor classes (capacity >= demand x1.2 built in)', mass_t=steel, co2_t=kit_co2_rec, tooling=1, steps=5,
      days_to_load=1.0, margin=ref['anchor_Q']/(PHI_ASD*ref['Tmax']) if ref['Tmax'] > 0 else 9.9, demount_pct=90),
]
OUT['ledger'] = led

# shell-geometry iteration measured on the equal-usable-floor sweep (pure 60deg cone -> 45deg on knee wall)
a0 = metrics(cone(60)); a0['Au'] = AU; a0['S_per_Au'] = cone(60)['S']/AU
a1 = metrics(cone(45, 2.1)); a1['S_per_Au'] = cone(45, 2.1)['S']/AU
OUT['geometry_iter'] = dict(pure60=dict(M=a0['M'], HD=a0['HD'], S_per_Au=a0['S_per_Au'], H=a0['H']),
                            knee45=dict(M=a1['M'], HD=a1['HD'], S_per_Au=a1['S_per_Au'], H=a1['H']))

base = design_foundation(12, V250)
def variant(label, **kw):
    d = design_foundation(kw.pop('n', 12), V250, **kw)
    return dict(label=label, HD=d['HD'], H=d['H'], steel_t=d['steel_t'], t_h=d['t_install_h'], Qreq=d['Qreq'],
                d_HD=100*(d['HD']/base['HD'] - 1) if base['HD'] else 0.0,
                d_steel=100*(d['steel_t']/base['steel_t'] - 1), d_t=100*(d['t_install_h']/base['t_install_h'] - 1),
                d_H=100*(d['H']/base['H'] - 1))
att = [variant('baseline n=12 a=45 hk=2.1'),
       variant('alpha 40', alpha=40), variant('alpha 50', alpha=50),
       variant('chord 1.5m, n=16', n=16, chord=1.5),
       variant('hub + n/2 spokes', hub=True),
       variant('2 anchors/node', per_node=2),
       variant('lighter shell sigma=150', sigma=150.0),
       variant('APC-vented lantern GCpi=0.18 [conditional]', gcpi=0.18)]
OUT['attempts'] = att


# ============================== G. extra analyses for the blueprint ====
# G1 flip-sensitivity of the architecture choice (cone-on-knee vs dome) to the [ASSUMED] aero inputs
def mcda_freq(shapes, alpha_w, N_draw=8000):
    rws = []
    for s in shapes:
        m = metrics(s)
        rws.append([m['M']/AU, m['HD']/AU, s['S']/AU, s['impact'], s['fab'], s['memb'], s['edgefree']])
    X = np.array(rws, float); Nn = np.zeros_like(X)
    for j in range(X.shape[1]):
        lo, hi = X[:, j].min(), X[:, j].max()
        Nn[:, j] = (X[:, j]-lo)/(hi-lo) if hi > lo else 1.0
        if j in (0, 1, 2, 3): Nn[:, j] = 1 - Nn[:, j]
    cnt = np.zeros(len(shapes))
    for _ in range(N_draw): cnt[np.argmax(Nn @ rng.dirichlet(alpha_w))] += 1
    return cnt/cnt.sum()
flip = []
for CLc in (0.25, 0.50):
    for Cfc in (0.60, 0.80):
        for CLd in (0.30, 0.50, 0.70):
            ss = [box(), cyl(), dome(), cone(60), cone(60, 1.5), cone(45, 2.1)]
            ss[2]['CL'] = CLd
            for k in (3, 4, 5): ss[k]['CL'] = CLc; ss[k]['Cf'] = Cfc
            f_u = mcda_freq(ss, np.ones(7)); f_s = mcda_freq(ss, np.array([2, 3, 1, 2, 1, 1, 2], float))
            flip.append(dict(CL_cone=CLc, Cf_cone=Cfc, CL_dome=CLd, cone45_uniform=float(f_u[5]), dome_uniform=float(f_u[2]),
                             cone45_safety=float(f_s[5]), dome_safety=float(f_s[2])))
OUT['flip'] = flip
OUT['flip_min_cone45_uniform'] = min(f['cone45_uniform'] for f in flip)
OUT['flip_min_cone45_safety'] = min(f['cone45_safety'] for f in flip)
OUT['flip_cone_wins_cases'] = sum(1 for f in flip if f['cone45_uniform'] > f['dome_uniform'])
OUT['flip_cases'] = len(flip)

# G2 anchor demand vs shell areal mass (n=12 and n=48 at WC4)
msens = []
for n_ in (12, 48):
    for sg in (50, 100, 150, 200, 300):
        d = design_foundation(n_, V250, sigma=float(sg))
        msens.append(dict(n=n_, sigma=sg, Ws=d['Ws'], U=d['U'], Tmax=d['Tmax'], Qreq=d['Qreq'], cls=d['anchor_Q'], na=d['anchors_per_node']))
OUT['mass_sens'] = msens

# G3 steel composition of the reference kit
ds = design_foundation(12, V250)
skirt_kg = 0.004*L*ds['skirt']*7850*1.15
OUT['steel_comp'] = dict(segments_kg=12*ds['seg_kg'], anchors_kg=12*20, skirts_kg=12*skirt_kg, hardware_kg=60.0,
                         total_kg=12*(ds['seg_kg'] + 20 + skirt_kg + 5.0))

# G4 ring-thrust check (steady, self-weight) for the nominal cone: T_ring = w R^2 / (2 sin(alpha))
w_kPa = SIGMA*G/1000.0
OUT['ring_thrust'] = dict(w=w_kPa, R=ref['D']/2, T_ring=w_kPa*(ref['D']/2)**2/(2*math.sin(math.radians(ALPHA))),
                          T_cap=275.0*2856/1000.0)

with open('results.json', 'w') as f: json.dump(OUT, f, indent=1, default=float)
print('ok')
