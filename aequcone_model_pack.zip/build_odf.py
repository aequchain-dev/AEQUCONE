#!/usr/bin/env python3
"""Builds the AEQUCONE ODF blueprint from results.json (numbers are pulled, never retyped)."""
import json, math, textwrap
W = 100
res = json.load(open('results.json'))
ref, gr, gv, sc = res['ref'], res['gravity_ref'], res['gravity_vs_kit'], res['steel_comp']
kit, shp, sw = res['kit_table'], res['shape_table'], res['cone_sweep']
out = []
OVER = []
def P(s=''): out.append(s)
def dbl(): P('═'*W)
def sgl(): P('─'*W)
def K(n, wc): return next(k for k in kit if k['n'] == n and k['wc'] == wc)
def S(name): return next(s for s in shp if s['name'] == name)
def SW(a, hk): return next(s for s in sw if s['alpha'] == a and abs(s['hk']-hk) < 1e-9)
def wrapl(l, width):
    if l == '': return ['']
    ind = len(l) - len(l.lstrip(' '))
    if l.lstrip().startswith(('• ', '- ')): sub = ' '*(ind+2)
    elif len(l.lstrip()) > 3 and l.lstrip()[1:3] in (') ', '. ') : sub = ' '*(ind+3)
    elif l.lstrip()[:1] == '[' and l.lstrip()[3:5] == '] ': sub = ' '*(ind+5)
    elif ' : ' in l[:18]: sub = ' '*(ind + l.index(' : ') - ind + 3)
    else: sub = ' '*ind
    return textwrap.wrap(l, width=width, subsequent_indent=sub) or ['']
def PW(l):
    for w in wrapl(l, W): P(w)
def para(text, ind=0):
    for l in textwrap.wrap(text, width=W-ind): P(' '*ind + l)
def sec(n, title): P(''); sgl(); P(f'{n}. {title}'); sgl(); P('')
def sub(n, title): P(''); P(f'{n} {title}'); P('')
def block(label, lines, kind='single', wrap=True):
    L, B, E, F = ('┌', '│', '└', '─') if kind == 'single' else ('╔', '║', '╚', '═')
    head = f'{L}{F} {label} '; P(head + F*(W-len(head))); P(B)
    for l in lines:
        if l == '': P(B); continue
        for w in (wrapl(l, W-3) if wrap else [l]):
            if len(w)+3 > W: OVER.append((len(w)+3, w[:70]))
            P(f'{B}  {w}')
    P(B); P(E + F*(W-1))
def table(headers, rows, prefix='', avail=None):
    avail = (W - len(prefix)) if avail is None else avail
    cols = [[str(h)] + [str(r[i]) for r in rows] for i, h in enumerate(headers)]
    wd = [max(len(c) for c in col) for col in cols]
    sepw = 3*(len(wd)-1)
    while sum(wd) + sepw > avail:
        i = max(range(len(wd)), key=lambda j: wd[j])
        if wd[i] <= 10: break
        wd[i] -= 1
    def emit(cells):
        wr = [textwrap.wrap(str(c), width=w) or [''] for c, w in zip(cells, wd)]
        for k in range(max(len(x) for x in wr)):
            P(prefix + ' │ '.join((wr[j][k] if k < len(wr[j]) else '').ljust(wd[j]) for j in range(len(wd))).rstrip())
    emit(headers); P(prefix + '─┼─'.join('─'*w for w in wd))
    for r in rows: emit(r)
def tblock(label, headers, rows, note=None):
    P(f'┌─ {label} ' + '─'*(W-5-len(label))); P('│')
    table(headers, rows, prefix='│  ', avail=W-3)
    if note:
        P('│')
        for l in wrapl(note, W-3): P('│  ' + l)
    P('│'); P('└' + '─'*(W-1))
def diagram(label, lines):
    block(label, lines, wrap=False)

# =============================================================== HEADER
dbl()
P('AEQUCONE v0.1 │ AXISYMMETRIC SHELL FRAMEWORK + AEQUBASE FOUNDATION KIT')
P('OPTIBEST / EFE concept-stage blueprint │ foundation-first │ shell-agnostic │ schematic, plan, design')
sgl()
P('Version   : 0.1'.ljust(53) + 'Status    : CONCEPT PLATEAU (conditional)')
P('Date      : 2026-10-10'.ljust(53) + 'Rigor     : MACRO')
P('Project   : AEQUCHAIN / EFE'.ljust(53) + 'Scale     : Global; household-community units')
P('Companion : AEQUCONE_drawing_set.pdf (3 sheets) │ model + builder scripts │ results.json')
sgl()
P('NOT A STAMPED STRUCTURAL DESIGN. Concept-stage engineering: every item marked [A] is an assumption')
P('that is a verification gate (section 9.6). No shelter or "tornado-proof" claim is made or implied.')
dbl()
P('')
sgl(); P('TABLE OF CONTENTS'); sgl(); P('')
for a, b in [('1. Executive Summary', '1'), ('2. Technical Specifications', '2'), ('3. System Architecture', '3'),
             ('4. Detailed Drawings', '4'), ('5. Manufacturing Specification', '5'), ('6. Materials Specification', '6'),
             ('7. Lifecycle Documentation', '7'), ('8. Scale Planning', '8'), ('9. OPTIBEST Verification Report', '9'),
             ('10. Certification (scoped)', '10'), ('APPENDIX A: Calculation basis (checkable)', 'A'), ('APPENDIX B: Visual prompts (T1/T2/T3)', 'B')]:
    P(f'    {a} '.ljust(W-8, '.') + f' [{b}]')

# =============================================================== 1. EXEC SUMMARY
sec(1, 'EXECUTIVE SUMMARY')
sub('1.1', 'Purpose statement')
block('PURPOSE', ['Define ONE parametric, scale-invariant, material-tier-agnostic construction framework in which an '
  'axisymmetric shell sits on a standardised, mass-producible, demountable ring foundation (AEQUBASE), so the same '
  'load path serves a 5 m entry shelter and a 30 m community hall, in entry or premium materials, with safety designed '
  'foundation-first. Optimal-across-all elements are fixed as invariants; conditional elements are switched by '
  'hazard, ground and tier.'], 'double')
sub('1.2', 'Answers to the questions asked')
pure = S('Cone 60deg'); knee = S('Cone 45deg + 2.1m knee'); dome = S('Hemisphere dome')
flipN, flipT = res['flip_cone_wins_cases'], res['flip_cases']
block('Q1  IS CONICAL BEST?  PARTLY - AND THE PURE STEEP CONE IS NOT', [
  '• TRUE: any body of revolution (cone, dome, drum) loads identically from every bearing; no "front". Same D and H, a cone '
  f'takes {100*res["cone_vs_cyl_same_D_H"]["F_ratio"]:.0f}% of the base shear and {100*res["cone_vs_cyl_same_D_H"]["M_ratio"]:.0f}% of the overturning moment of a drum '
  '(checked analytically: 1/2 and 1/3 for uniform pressure). A cone is a developable surface: flat-sheet or flat-facet '
  'manufacture, no double-curved moulds.',
  f'• FALSE as pictured: at EQUAL USABLE FLOOR (40 m2, 2.1 m headroom) a pure 60 deg cone costs {pure["M"]/knee["M"]*100-100:+.0f}% moment, '
  f'{pure["HD"]/knee["HD"]*100-100:+.0f}% hold-down and {pure["S_per_Au"]/knee["S_per_Au"]*100-100:+.0f}% shell area compared with a 45 deg conical roof on a 2.1 m knee wall '
  f'(M {pure["M"]:.0f} vs {knee["M"]:.0f} kN.m; hold-down {pure["HD"]:.0f} vs {knee["HD"]:.0f} kN). Height costs moment; the perimeter of a pure cone is unusable.',
  f'• The dome is a real rival (lower moment: {dome["M"]:.0f} kN.m). Cone-on-knee beats it in {flipN} of {flipT} aero-assumption cases '
  f'(uniform weights) and {sum(1 for f in res["flip"] if f["cone45_safety"]>f["dome_safety"])} of {flipT} under safety weights, so the shell choice is decided by wind-tunnel gate V1. '
  'The FOUNDATION is identical either way: that is the invariant.'])
t = K(12, 'WC4')
block('Q2  HOW SHOULD FOUNDATIONS BE LAID?', [
  'Not as a cast raft. Lay a RING of identical steel segments (chord 2.000 m) on screw anchors driven to a logged torque, '
  'one anchor per node, with a continuous skirt fin. The ring is the tension tie for the shell, the hold-down distributor and '
  'the sliding key in one part. Sequence: site gate > set out > drive anchors (torque-logged) > set segments > close and '
  'torque ring > skirt + compacted backfill > erect shell. About 8 working hours for the 7.7 m reference unit, loadable '
  'immediately (no cure time).'])
block('Q3  HOW ENHANCED?  (measured deltas, section 9.3)', [
  f'• Ring + anchors vs cast raft: foundation mass {gr["mass_t"]:.1f} t -> {sc["total_kg"]/1000:.2f} t ({100*gv["mass_ratio"]:.1f}% of raft); embodied CO2e {gr["co2_t"]:.1f} t -> '
  f'{gv["kit_co2_recycled"]:.1f} t (recycled steel) or {gv["kit_co2_virgin"]:.1f} t (virgin steel) - indicative factors [A].',
  f'• Constant-chord n-gon segment: {res["ledger"][0]["tooling"]} tooling sets -> {res["ledger"][2]["tooling"]}; one segment section covers n = 8..48 and WC1..WC4.',
  '• Torque-as-proof: every anchor is load-qualified by its installation torque (Qult = Kt x T), so QA is built into mass production.',
  '• Capacity design: anchors carry >= 3x the computed demand on the reference unit; the foundation outlasts the shell by design.'])
block('Q4  CAN FOUNDATIONS OF CONICAL STRUCTURES BE MASS PRODUCED?  YES', [
  f'• One segment (RHS 150x100x6 x 2.0 m, {ref["seg_kg"]:.0f} kg) and one anchor ladder (A1 60 | A2 100 | A3 150 | A4 250 kN) cover every size in the ladder. '
  'Ring diameter is set only by the NUMBER of segments: D = 2.0 / sin(180/n).',
  '• Precast radial-rib wind-turbine foundations exist but sit in active patent families (section 9.8); AEQUBASE is deliberately a '
  'different architecture (ring + screw anchors + skirt, any material) pending a freedom-to-operate review.',
  '• Spun-cast concrete suits tubes and piles, not 45 deg shells: rejected for the shell, kept as an option for a central core tube.'])
berm2 = next(b for b in res['berm'] if b['berm_h'] == 2.1); fl15 = next(f for f in res['flotation'] if f['water_depth'] == 1.5)
block('Q5  HEIGHT BELOW / ABOVE GROUND', [
  f'• Above: ring top +0.15 m over grade (splash, drainage). Apex {0.15+2.1+ref["D"]/2*math.cos(math.pi/12):.2f} m (H/D = {ref["H"]/ref["D"]:.2f}). Taller costs moment roughly with H squared; do not exceed the 45 deg family.',
  f'• Below: skirt {K(12,"WC1")["skirt"]:.2f}-{K(12,"WC4")["skirt"]:.2f} m by wind class; anchors >= 3.0 m (>= 12 helix diameters). Habitable sub-grade core cell only if the design water table is >= 1.5 m below floor '
  f'(weight/buoyancy {fl15["margin"]:.2f} at 1.5 m; {next(f for f in res["flotation"] if f["water_depth"]==1.0)["margin"]:.2f} at 1.0 m = floats).',
  f'• Berm to knee height (2.1 m): base shear {berm2["F_pct"]:.0f}% and moment {berm2["M_pct"]:.0f}% of unbermed; adds drainage and moisture duties.'])

sub('1.3', 'Key specifications (reference unit R-12, WC4)')
tblock('KEY SPECIFICATIONS', ['Parameter', 'Value', 'Basis'], [
  ['Ring / nodes', '12 segments, chord 2.000 m, 12 nodes', 'n-gon, D = 2.0 / sin(180/n)'],
  ['Diameter (nodes / flats)', f'{ref["D"]:.2f} m / {2*ref["D"]/2*math.cos(math.pi/12):.2f} m', 'model'],
  ['Shell', '12 wall + 12 roof flat facets, 45 deg roof on 2.1 m knee', 'section 2.4'],
  ['Apex above grade', f'{0.15+2.1+ref["D"]/2*math.cos(math.pi/12):.2f} m (faceted); {ref["H"]+0.15:.2f} m circumscribed-cone model', 'ring top +0.15'],
  ['Design wind', '250 mph = 111.8 m/s 3-s gust (WC4), ICC 500 GCpi +/-0.55', 'FEMA P-361 / ICC 500 basis'],
  ['Wind demand', f'F {ref["F"]:.0f} kN | M {ref["M"]:.0f} kN.m | breach uplift {ref["U"]:.0f} kN', 'Cf 0.6, CL 0.25 [A]'],
  ['Shell weight', f'{ref["Ws"]:.0f} kN (200 kg/m2 [A])', 'T1 ferrocement-class'],
  ['Anchor demand', f'T = {ref["Tmax"]:.1f} kN/node; Qreq {ref["Qreq"]:.1f} kN -> class A1 60 kN', 'x1.2 = ASD FS2 with 0.6W'],
  ['Install torque', f'>= {ref["torque"]:.1f} kN.m per anchor (Kt 23 1/m [A])', 'log every anchor'],
  ['Skirt fin', f'4 mm x 2.0 m x {ref["skirt"]:.2f} m', 'passive, phi 32 gamma 18 [A]'],
  ['Foundation steel', f'{sc["total_kg"]/1000:.2f} t ({100*sc["skirts_kg"]/sc["total_kg"]:.0f}% skirt, {100*sc["segments_kg"]/sc["total_kg"]:.0f}% segments, {100*sc["anchors_kg"]/sc["total_kg"]:.0f}% anchors)', 'section 6.1'],
  ['Install time', f'{ref["t_install_h"]:.0f} h, 3-person crew', 'section 5.5 [A]']])

sub('1.4', 'EFE compliance (honest status per principle)')
table(['Principle', 'Status', 'Evidence and caveat'], [
  ['Sustainable', 'PASS (cond.)', f'CO2e {100*gv["co2_ratio_recycled"]:.0f}-{100*gv["co2_ratio_virgin"]:.0f}% of a cast raft; NOT carbon-negative at embodied stage'],
  ['Renewable', 'PARTIAL', 'Foundation is metal: indefinitely cyclable, not grown. Shell tiers offer timber/bamboo/earth'],
  ['Accessible', 'PASS (cond.)', 'Commodity RHS + screw anchors; small units need no heavy plant [A]; fallback ballast ring for WC1'],
  ['Open', 'PASS (cond.)', 'Generic geometry; patent landscape mapped (9.8); freedom-to-operate review is gate V5'],
  ['Local-first', 'PASS', 'Any steel workshop makes P1/P3/P4; screw anchors regional; shell tier by local material'],
  ['Circular', 'PASS (target)', '>= 90% of foundation mass recoverable by unscrewing/unbolting; field trials gate V8'],
  ['Durable', 'CONDITIONAL', '50-yr design life needs coating + corrosion allowance per soil corrosivity class; gate V4']])

sub('1.5', 'Scale pathway')
table(['Stage', 'Scope', 'Duration [A]', 'Exit criterion'], [
  ['P0 bench', 'node + anchor + segment tests', '8-12 weeks', 'V2/V3 pass: torque-capacity, node proof load'],
  ['P1 full unit', 'one R-12, instrumented, 1 site', '4-6 months', 'V1 wind-tunnel/CFD closed; measured vs model'],
  ['P2 pilot', '10 units, 3 ground types', '9-12 months', 'install <= 1 day; zero rework; V4/V8 data'],
  ['P3 series', '100-1,000 units, 3 fabrication nodes', '12-24 months', 'kit cost and QA yield stable'],
  ['P4 mass', '10,000+ units, regional nodes', '3-5 years', 'open drawings + local certification routes']])

sub('1.6', 'Certification summary (scoped)')
para('Concept plateau reached within model fidelity: 7 enhancement attempts produced no unconditional gain above the 10% '
     'model-noise floor, one conditional vector is logged (APC-vented lantern), and 9 external gates are open. '
     'The PREMIUM stamp is deliberately NOT applied: it would assert more than the evidence supports. See section 10.')

# =============================================================== 2. TECHNICAL SPECIFICATIONS
sec(2, 'TECHNICAL SPECIFICATIONS')
sub('2.1', 'Invariants vs conditionals (what is optimal everywhere, what depends)')
table(['Class', 'Element', 'Rule'], [
  ['INVARIANT', 'Axisymmetric plan, n >= 8', 'rotational symmetry; any bearing, same load path'],
  ['INVARIANT', 'Constant-chord ring segment', 'chord 2.000 m; size = number of segments'],
  ['INVARIANT', 'Continuous load path', 'hip rib > shoe > node block > anchor sleeve > anchor'],
  ['INVARIANT', 'Torque-logged anchors, 1 per node min', 'robustness even if computed demand is zero'],
  ['INVARIANT', 'Capacity design', 'foundation resistance >= 1.25 x shell yield; sacrificial cladding fails first'],
  ['INVARIANT', 'Demountable, no concrete in ground', 'bolted ring, unscrewable anchors'],
  ['CONDITIONAL', 'Wind class WC1..WC4', 'sets skirt depth, anchor class, section check'],
  ['CONDITIONAL', 'Ground switch', 'screw anchors | rock anchors | ballast ring (WC1-2 only)'],
  ['CONDITIONAL', 'Shell shape', '45 deg cone-on-knee (default) | dome | rolled true cone'],
  ['CONDITIONAL', 'Material tier T1/T2/T3', 'same interfaces, performance classes (section 3.4)'],
  ['NICE-TO-HAVE', 'Core cell, berm, APC-vented lantern, hub-and-spoke', 'enabled by site; never required by the kit']])

sub('2.2', 'Reference unit R-12')
block('SPECIFICATION - R-12', [
  f'Ring            : 12 x RHS 150x100x6, chord 2.000 m, circumradius {ref["D"]/2:.3f} m, apothem {ref["D"]/2*math.cos(math.pi/12):.3f} m',
  f'Floor           : {12/4*4/math.tan(math.pi/12):.1f} m2 polygon, all >= 2.1 m clear (knee wall 2.1 m)',
  f'Shell           : facets: 12 wall panels 2.0 x 2.1 m + 12 roof triangles at 45 deg; apex cap',
  f'Foundation      : 12 anchors A1 (60 kN), skirt fin {ref["skirt"]:.2f} m, ring top +0.15 m above grade',
  f'Loads (WC4)     : F {ref["F"]:.0f} kN, M {ref["M"]:.0f} kN.m, uplift {ref["U"]:.0f} kN (breach), shell {ref["Ws"]:.0f} kN',
  f'Segment check   : Mseg {ref["Mseg"]:.1f} vs {0.9*39.5:.1f} kN.m cap (RHS 150x100x6); ring thrust {res["ring_thrust"]["T_ring"]:.0f} vs {res["ring_thrust"]["T_cap"]:.0f} kN',
  'CRITICAL: concept-stage values. Node, shell and connection design are gate V3.'], 'double', wrap=False)

sub('2.3', 'Shape study: equal function (40 m2 usable floor, 2.1 m headroom, 250 mph, breach case)')
table(['Architecture', 'D m', 'H m', 'S/Au', 'F kN', 'M kN.m', 'Uplift', 'Hold-down', 'Impact'],
      [[s['name'], f'{s["D"]:.1f}', f'{s["H"]:.1f}', f'{s["S_per_Au"]:.2f}', f'{s["F"]:.0f}', f'{s["M"]:.0f}', f'{s["U"]:.0f}', f'{s["HD"]:.0f}', f'{s["impact"]:.2f}'] for s in shp])
P('')
para('S/Au = shell area per usable floor area (material, cost, carbon proxy). Hold-down = uplift + M/lever - 0.9 x shell weight (kN '
     'the foundation must supply). Impact = mean normal-impact energy fraction of a horizontal missile (1.0 = face-on); '
     'curvature and slope help in reality but ICC 500 tests are normal-incidence, so no code credit is claimed.')
P('')
wu = dict(zip(res['mcda_names'], res['mcda_win_uniform'])); ws = dict(zip(res['mcda_names'], res['mcda_win_safety']))
table(['Architecture', 'Wins, uniform weights', 'Wins, safety-weighted'], [[n, f'{100*wu[n]:.1f}%', f'{100*ws[n]:.1f}%'] for n in res['mcda_names']])
P('')
para(f'Weights were sampled (20,000 Dirichlet draws), not chosen. Pareto: "Cone 60deg + 1.5m knee" is dominated by the 45 deg / 2.1 m knee. '
     f'ASSUMPTION FLIP TEST: varying cone lift CL 0.25-0.50, cone Cf 0.6-0.8 and dome CL 0.3-0.7 (12 cases), the cone-on-knee beats the dome '
     f'in {flipN} (uniform) and {sum(1 for f in res["flip"] if f["cone45_safety"]>f["dome_safety"])} (safety-weighted) of {flipT}. The dome wins only when the cone is aerodynamically pessimistic. '
     'Scoring of fabrication (developable = 1.0, dome = 0.5) and membrane efficiency are judgments, not measurements.')

sub('2.4', 'Cone-family optimum (equal usable floor)')
rows = []
for a in (40, 45, 50, 55, 60, 70, 75):
    x0, x2 = SW(a, 0.0), SW(a, 2.1)
    rows.append([f'{a}', f'{x0["M"]:.0f}', f'{x0["HD"]:.0f}', f'{x0["S_per_Au"]:.2f}', f'{x2["M"]:.0f}', f'{x2["HD"]:.0f}', f'{x2["S_per_Au"]:.2f}', f'{x2["H"]:.1f}'])
table(['Roof deg', 'M pure', 'HD pure', 'S/Au pure', 'M +2.1m knee', 'HD +2.1m knee', 'S/Au +2.1m', 'H m'], rows)
P('')
para('DECISION: nominal 45 deg on a 2.1 m knee wall; window 40-50 deg. 40 deg is slightly better on paper (about -7% hold-down, -10% height) '
     'but inside the model noise floor, and it sits where suction rises and wind-tunnel data thin out (grain-bin cone roofs and a 30 deg CFD case show '
     'strong local suction). Moment grows steeply above 55 deg: the intuitive tall cone is the wrong end of this curve.')

sub('2.5', 'Wind classes and load basis')
tblock('WIND CLASSES', ['Class', 'Design 3-s gust', 'Use', 'Note'], [
  ['WC1', '45 m/s (~100 mph)', 'gale zones', 'ballast ring may replace anchors (low uplift) [A]'],
  ['WC2', '60 m/s (~134 mph)', 'strong storm', 'screw anchors, shallow skirt'],
  ['WC3', '80 m/s (~179 mph)', 'cyclone / severe', 'screw anchors, mid skirt'],
  ['WC4', '111.8 m/s (250 mph)', 'ICC 500 / FEMA P-361 basis', 'foundation capacity only; shelter claim needs tested envelope']],
  note='Basis: ASCE 7 Exposure C profile Kz = 2.01 (z/274.3)^(2/9.5), q = 0.613 Kz V^2, Kd = Kzt = Ke = 1. Round-structure Cf 0.5-0.6 '
       '(supercritical, moderately smooth) bracketed 0.5-0.8 for rough surfaces. ASCE 7-22 Chapter 32 tornado provisions target Risk Cat III/IV at about EF2 or '
       'less; the 250 mph basis is the ICC 500 / FEMA P-361 shelter figure.')
P('')
tbl = []
for wc in ('WC1', 'WC2', 'WC3', 'WC4'):
    k = K(12, wc); tbl.append([wc, f'{k["F"]:.0f}', f'{k["M"]:.0f}', f'{k["U"]:.0f}', f'{k["Tmax"]:.1f}', f'{k["Qreq"]:.1f}', f'A1 {k["anchor_Q"]}', f'{k["skirt"]:.2f}', f'{k["steel_t"]:.2f}'])
table(['R-12', 'F kN', 'M kN.m', 'Uplift kN', 'T/node kN', 'Qreq kN', 'Anchor', 'Skirt m', 'Steel t'], tbl)
P('')
block('ASSUMPTIONS [A] - EACH IS A VERIFICATION GATE', [
  '[A1] Cone-on-knee Cf 0.6 (0.5-0.8) and external lift CL 0.25 (0.05-0.5); breach internal pressure +0.55 (ICC 500, partially enclosed). Gate V1.',
  '[A2] Shell areal mass 200 kg/m2 (T1). Lighter tiers raise anchor demand: sensitivity in 9.5. Gate V3.',
  '[A3] Soil: dense granular, phi 32 deg, gamma 18 kN/m3; passive mobilisation factor 0.5. Gate V2.',
  '[A4] Anchor Kt = 23 1/m (conservative end of published 23-33); depth >= 12 helix diameters for tension correlation. Gate V2.',
  '[A5] Embodied carbon factors: concrete 0.13 kgCO2e/kg + rebar; recycled steel 0.6, virgin steel 1.9 kgCO2e/kg (indicative). Gate: EPDs.',
  '[A6] Loads computed on the circumscribed circular frustum (conservative wind area; self-weight within the sampled +/-15%).'])

sub('2.6', 'Foundation sizing ladder (WC4, breach case) - one segment, six sizes')
rows = []
for n in (8, 12, 16, 24, 36, 48):
    k = K(n, 'WC4'); fl = (n/4)*4.0/math.tan(math.pi/n); ac = [60, 100, 150, 250, 400, 650].index(k['anchor_Q'])+1
    rows.append([n, f'{k["D"]:.1f}', f'{k["H"]:.1f}', f'{fl:.0f}', f'{k["Tmax"]:.0f}', f'{k["Qreq"]:.0f}', f'A{ac} {k["anchor_Q"]}', f'{k["torque"]:.1f}', f'{k["Mseg"]:.1f}', f'{k["skirt"]:.2f}', f'{k["steel_t"]:.2f}', f'{k["t_install_h"]:.0f}'])
table(['n', 'D m', 'H m', 'Floor', 'T kN', 'Qreq', 'Anchor', 'Torq', 'Mseg', 'Skirt', 'Steel', 'Inst h'], rows)
P('')
para('Floor = m2 | T = anchor tension per node (kN) | Qreq (kN) | Torq = install torque (kN.m) | Mseg (kN.m) | Skirt (m) | Steel (t) | Inst = install hours')
P('')
para('All sizes and all wind classes use ONE segment section: the worst segment moment in the ladder is '
     f'{max(k["Mseg"] for k in kit):.1f} kN.m against 35.6 kN.m design capacity (0.9 Mp, RHS 150x100x6). n >= 24 use a truncated vented lantern '
     '(r_top/R = 0.3, 0.5, 0.6) so apex height stays 7-8 m. Anchor demand is small because the shell dead weight offsets most breach uplift; '
     'a lighter shell moves demand up the anchor ladder, not off it:')
P('')
rows = [[m['n'], m['sigma'], f'{m["Ws"]:.0f}', f'{m["Tmax"]:.0f}', f'{m["Qreq"]:.0f}', f'A{[60,100,150,250,400,650].index(m["cls"])+1} {m["cls"]}'] for m in res['mass_sens']]
table(['n', 'Shell kg/m2', 'Shell kN', 'T kN/node', 'Qreq kN', 'Anchor class'], rows)

sub('2.7', 'Ground switch (conditional element)')
table(['Ground', 'Variant', 'Rule'], [
  ['Medium-dense granular, stiff clay', 'F-S screw anchors (default)', 'torque-logged; embed >= 12 helix dia; load test 2% min'],
  ['Loose / soft / possibly liquefiable', 'F-S through weak layer', 'anchor tips in competent stratum; liquefaction check (gate V6)'],
  ['Rock within ~1.5 m', 'F-R grouted rock anchors', 'same node sleeve; skirt replaced by shear keys'],
  ['Cobbles, boulders, rubble fill', 'pre-drill or F-R', 'refusal logged; never accept a short anchor silently'],
  ['Expansive clay', 'F-S below active zone', 'void former under floor; skirt isolated from heave'],
  ['High water table', 'F-S, no sub-grade cell', 'buoyant unit weight in capacity; corrosion class raised'],
  ['No plant / obstructed, WC1 only', 'F-B ballast trench ring', 'gravel-filled trench round ring; sliding by skirt [A]']])

sub('2.8', 'Height, embedment, berm and flotation rules')
rows = [[n] + [f'{K(n, wc)["skirt"]:.2f}' for wc in ('WC1', 'WC2', 'WC3', 'WC4')] for n in (8, 12, 16, 24, 36, 48)]
table(['n (skirt depth, m)', 'WC1', 'WC2', 'WC3', 'WC4'], rows)
P('')
table(['Berm to height m', 'Base shear %', 'Moment %'], [[f'{b["berm_h"]:.1f}', f'{b["F_pct"]:.0f}', f'{b["M_pct"]:.0f}'] for b in res['berm']])
P('')
table(['Water table below floor m', 'Core cell weight kN', 'Buoyancy kN', 'Weight/buoyancy'],
      [[f'{f["water_depth"]:.1f}', f'{f["weight"]:.0f}', f'{f["buoyancy"]:.0f}', ('n/a' if f['margin'] is None else f'{f["margin"]:.2f}')] for f in res['flotation']])
P('')
block('RULES', [
  '• Ring top = FFL = +0.15 m above external grade. Nothing habitable lower than the flotation rule allows; minimum margin 1.1 on weight/buoyancy.',
  '• Core cell D3.0 x 2.4 m only where margin >= 1.1 with the SITE water table (design, not seasonal low). Otherwise add tension anchors for the buoyant surplus.',
  '• Berm slope toe >= 1.5 x berm height from the wall; drainage and damp-proofing are the price of the berm.',
  '• Apex height capped by the family (H/D about 0.77 at n = 12; lantern truncation above that). Height is paid for in moment.'])

sub('2.9', 'Tolerances and acceptance (concept values [A])')
table(['Feature', 'Tolerance', 'Check'], [
  ['Node radial position', '+/-10 mm', 'string or total station from centre peg'],
  ['Anchor plumb / position', '+/-2 deg / +/-25 mm', 'inclinometer at start of drive'],
  ['Ring level over any 2 m', '+/-3 mm; whole ring +/-8 mm', 'laser level, shims P4'],
  ['Segment chord length', '2000 +/-2 mm', 'jig'],
  ['Node block bore / bolt pitch', '+/-0.5 mm', 'go/no-go gauge'],
  ['Installed torque', '>= specified (class Qult / 23)', 'logged, tagged; reject if below'],
  ['Skirt verticality / backfill', '+/-1 deg; compaction in 200 mm lifts', 'plate test at 3 points']])

# =============================================================== 3. SYSTEM ARCHITECTURE
sec(3, 'SYSTEM ARCHITECTURE')
sub('3.1', 'Module architecture')
diagram('MODULES', [
 '  ┌─────────────┐',
 '  │  SITE GATE  │   geotech │ corrosivity │ water table │ wind class │ code and licensed engineer',
 '  └──────┬──────┘',
 '         ▼',
 '  ┌──────────────────────────────────────────────────────────────┐',
 '  │ AEQUBASE  invariant │ mass-produced │ demountable            │',
 '  │ P1 ring segments ─ P2 screw anchors ─ P3 skirt fin ─ P4 set  │',
 '  └───────────────────────────────┬──────────────────────────────┘',
 '                                  │ NODE INTERFACE (12 hip shoes, M20 pattern, rated N60..N250)',
 '                                  ▼',
 '  ┌──────────────────────────────────────────────────────────────┐',
 '  │ SHELL MODULE  conditional: tier │ shape │ local material     │',
 '  │ 45 deg cone-on-knee (default) │ dome │ rolled true cone      │',
 '  └───────────────────────────────┬──────────────────────────────┘',
 '                                  ▼',
 '   ┌────────────────┐   ┌────────────────────┐   ┌───────────────────────┐',
 '   │ OPENINGS       │   │ ENVELOPE / SKIN    │   │ SERVICES, CORE CELL   │',
 '   │ framed, rated  │   │ replaceable        │   │ optional              │',
 '   └────────────────┘   └────────────────────┘   └───────────────────────┘'])
sub('3.2', 'Load path and failure order')
diagram('LOAD PATH (every wind bearing identical)', [
 '  wind (any bearing) ─► facets ─► hip ribs (12) ─► hip shoes ─► NODE BLOCKS ─► anchor sleeves',
 '                                                                         └─► anchors ─► ground',
 '  breach uplift      ─► same chain, in tension',
 '  overturning M      ─► node loads T / N varying as cos(theta) around the ring',
 '  base shear F       ─► ring (diaphragm) ─► skirt fin ─► passive soil',
 f'  shell thrust       ─► ring tension {res["ring_thrust"]["T_ring"]:.0f} kN against {res["ring_thrust"]["T_cap"]:.0f} kN section capacity ({100*res["ring_thrust"]["T_ring"]/res["ring_thrust"]["T_cap"]:.1f}% used)'])
P('')
table(['Order', 'Element', 'Intended behaviour (capacity design, each stage >= 1.25 x previous [A])'], [
  ['1', 'Skin / cladding / seals', 'sacrificial, replaceable; fails first, vents pressure'],
  ['2', 'Shell fasteners', 'ductile; fail before panels'],
  ['3', 'Shell panels, hip ribs', 'designed to yield, not shatter'],
  ['4', 'Hip shoes, node bolts', 'over-strength to ribs'],
  ['5', 'Ring segments, node blocks', 'stay elastic at shell yield'],
  ['6', 'Anchors, skirt (last)', 'resist >= 3x computed demand on R-12; foundation outlives shell']])
sub('3.3', 'Node interface (the invariant that makes tiers interchangeable)')
table(['Parameter', 'Value [A]', 'Note'], [
  ['Node block', '260 x 260 x 12 mm plate box, sleeve D70', 'one part number, all sizes'],
  ['Segment-to-block', '4 x M20 per segment end', 'ring turns 360/n deg per node'],
  ['Hip shoe-to-block', '2 x M16', 'shell module owns the shoe'],
  ['Anchor coupling', 'sleeve + pin or thread, tensile rated', 'class N60 / N100 / N150 / N250 kN'],
  ['Skirt attachment', 'bolt-on fin, trimmed per wind class', 'extension strip allows WC upgrade in place'],
  ['Spare provision', 'second sleeve boss on N100+ blocks', 'allows 2 anchors/node retrofit']])
sub('3.4', 'Material tier matrix (same interfaces, performance classes)')
table(['Module', 'T1 Proto', 'T2 Advanced', 'T3 Apex (target)'], [
  ['P1 ring segment', 'recycled RHS, galvanised', 'basalt-fibre geopolymer / BFRP box + steel node', 'CNT-polymer composite box [TRL-gated]'],
  ['P2 anchor', 'recycled steel, galvanised', 'steel + duplex polymer-ceramic coat', 'steel core + wear-barrier coating'],
  ['P3 skirt fin', 'recycled steel sheet 4 mm', 'GFRP/BFRP sheet 6 mm (no corrosion)', 'same as T2'],
  ['Shell facets', 'bamboo/FSC timber + ferrocement', 'BFRP + hemp/mycelium sandwich', 'CNT / nano-diamond sandwich'],
  ['Shell mass target', '~200 kg/m2', '~100 kg/m2', '~50 kg/m2'],
  ['Upgrade path', '-> T2: swap shell, keep ring', '-> T3: swap ring segments 1:1', 'foundation never re-dug']])
P('')
para('T2 and T3 entries are performance targets written to the node interface class, not verified products. Ring-segment performance class: '
     'Mp >= 36 kN.m, node proof >= 90 kN uplift, bolt pattern per 3.3. A tier passes only by test against that class.')

# =============================================================== 4. DETAILED DRAWINGS
sec(4, 'DETAILED DRAWINGS')
sub('4.1', 'Drawing index')
table(['Sheet', 'File', 'Content'], [
  ['1/3', 'AEQUCONE_drawing_set.pdf p1', 'R-12 elevation, section A-A, plan, notes (to scale)'],
  ['2/3', 'AEQUCONE_drawing_set.pdf p2', 'node plan/section, parts schedule, 6-step assembly, size ladder, selection chart'],
  ['3/3', 'AEQUCONE_drawing_set.pdf p3', 'study evidence: shapes, cone sweep, raft vs kit, Monte Carlo, flotation']])
sub('4.2', 'Elevation, R-12 (schematic)')
cx = 30; rr = 7; rows_ = []
canvas = [[' ']*72 for _ in range(rr+9)]
def put(r, c, ch):
    if 0 <= r < len(canvas) and 0 <= c < 72: canvas[r][c] = ch
put(0, cx, '▲')
for r in range(1, rr+1):
    put(r, cx-2*r, '╱'); put(r, cx+2*r, '╲')
    for f in (0.268, 0.732):
        put(r, cx - int(round(f*2*r)), '╱'); put(r, cx + int(round(f*2*r)), '╲')
    put(r, cx, '│')
for c in range(cx-2*rr, cx+2*rr+1): put(rr, c, '─' if canvas[rr][c] == ' ' else canvas[rr][c])
for r in range(rr+1, rr+5):
    for f in (-1, -0.732, -0.268, 0.268, 0.732, 1):
        put(r, cx + int(round(f*2*rr)), '│')
for r in range(rr+2, rr+5): put(r, cx-3, '│'); put(r, cx+3, '│')
put(rr+1, cx-3, '┌'); put(rr+1, cx+3, '┐')
for c in range(cx-2, cx+3): put(rr+1, c, '─')
for i, ch in enumerate('DOOR'): put(rr+3, cx-2+i, ch)
for c in range(cx-2*rr-6, cx+2*rr+7): put(rr+5, c, '═')
for f in (-1, -0.732, -0.268, 0.268, 0.732, 1): put(rr+5, cx + int(round(f*2*rr)), '╧')
for c in range(cx-2*rr-6, cx+2*rr+7): put(rr+6, c, '░')
for r in range(rr+7, rr+9):
    for f in (-1, -0.268, 0.268, 1): put(r, cx + int(round(f*2*rr)), '┊')
ann = {0: f'apex +{0.15+2.1+ref["D"]/2*math.cos(math.pi/12):.2f} m above grade', 2: '45 deg roof, 12 flat facets', 3: 'hip ribs land on the 12 nodes',
       rr: 'knee line +2.25 m', rr+2: 'knee wall: 12 flat panels 2.0x2.1', rr+3: 'clear 2.10 m; door 1.0 x 2.0',
       rr+5: 'ring top = FFL +0.15 m', rr+6: 'external grade 0.00', rr+7: f'skirt fin {ref["skirt"]:.2f} m (hidden)', rr+8: 'anchors >= 3.0 m (hidden)'}
lines_ = []
for r, row in enumerate(canvas):
    s = ''.join(row).rstrip(); a = ann.get(r, '')
    lines_.append((s.ljust(54) + '◄ ' + a) if a else s)
diagram('ELEVATION (view on facet S12)', ['  ' + l if l.strip() else '' for l in lines_])
sub('4.3', 'Section A-A and plan')
diagram('SECTION A-A (through opposite nodes, not to scale below grade)', [
 '                                  ▲ apex cap (compression ring / vent lantern option)',
 '                               ╱  │  ╲',
 '                            ╱ hip rib  ╲                    shell: flat facets, 45 deg',
 '                         ╱      │      ╲',
 '                      ╱─────────┼─────────╲   ◄ knee line',
 '                      ║         │         ║   ◄ knee wall 2.10 m clear',
 '                      ║   living volume    ║',
 '       ═══════════════╩═════════════════════╩═══════════  ring + node block; FFL +0.15',
 '       ░░░░ gravel pad ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  grade 0.00',
 '                      ┃                     ┃   ◄ skirt fin 1.04 m (WC4)',
 '                      ┃    ┌ ─ ─ ─ ─ ─ ┐     ┃',
 '                      ┃    core cell (opt.)  ┃   ◄ only if water table >= 1.5 m below floor',
 '                      ┃    └ ─ ─ ─ ─ ─ ┘     ┃',
 '                      ┃                     ┃   ◄ anchor shaft, embed >= 12 helix dia',
 '                     ═╋═                   ═╋═  ◄ helices D200 x2 (class A1)'])
diagram('PLAN AT FFL (S12 = door facet)', [
 '                          N7 ●━━━━━━━━━━● N6',
 '                           ╱ ╲        ╱ ╲',
 '                      N8 ●    ╲      ╱    ● N5          ● node + screw anchor (12)',
 '                        ┃      ╲    ╱      ┃            ━ ring segment S1..S12, chord 2.000',
 '                  N9 ●          ╲  ╱         ● N4       ╱ hip rib to apex',
 '                    ┃            ╲╱           ┃',
 '                    ┃     ────────●────────   ┃         across flats 7.46 m, nodes 7.73 m',
 '                 N10 ●            ╱╲          ● N3      floor 44.8 m2 (polygon)',
 '                      ┃          ╱  ╲        ┃',
 '                   N11 ●       ╱      ╲      ● N2',
 '                           ╲  ╱          ╲  ╱',
 '                          N12 ●━━━━━━━━━━● N1',
 '                                S12  DOOR 1.0 m'])
sub('4.4', 'Node assembly (exploded)')
diagram('NODE N (P1 x2, node block, P2, P3, P4)', [
 '                      hip shoe (shell module) ─┐',
 '                                            ╔══╧══╗',
 '       segment A ───────────────────────────╢NODE ╟────────────────────────── segment B',
 '       RHS 150x100x6   4 x M20 each end     ║BLOCK║     4 x M20 each end     RHS 150x100x6',
 '                                            ╚══╤══╝',
 '                                               │ sleeve D70 (spare boss on N100+)',
 '                         skirt fin ─ ─ ─ ─ ─ ─ ┃ ─ ─ ─ ─ ─ ─ skirt fin  (bolt-on, 4 mm)',
 '                                               ┃ P2 anchor shaft, torque-logged',
 '                                             ══╋══ helix D200 (x2)'])

# =============================================================== 5. MANUFACTURING
sec(5, 'MANUFACTURING SPECIFICATION')
sub('5.1', 'Process sequence with checkpoints (T1)')
table(['Part', 'Step', 'Process', 'Checkpoint'], [
  ['P1', '1', 'cut RHS 150x100x6 to 2000 chord, square ends, weld end plates', 'length +/-2 mm in jig, 100%'],
  ['P1', '2', 'fabricate node block 260x260x12 box, bore sleeve D70', 'go/no-go bore + bolt pattern, 100%'],
  ['P1', '3', 'hot-dip galvanise (>= 85 um) or duplex coat', 'coating thickness 5 readings per batch'],
  ['P2', '1', 'cut shaft, weld drive coupling, press and weld 2 plate helices D200', 'helix pitch/diameter +/-3 mm, 100%'],
  ['P2', '2', 'galvanise; proof torque on 1 in 50 to 1.25 x rating', 'no yield, no weld crack'],
  ['P3', '1', 'shear 4 mm sheet 2000 x 1040, form stiffening flange, punch', 'flatness, hole pitch, 100%'],
  ['P4', '1', 'M20 8.8 galvanised sets, shims, torque tags, QR labels', 'kit count check against R-12 list']])
sub('5.2', 'Equipment and local-first alternatives')
table(['Operation', 'Standard', 'Local alternative'], [
  ['Cut / drill', 'plasma or laser, drill line', 'band saw, magnetic drill, hand grinder'],
  ['Weld', 'MIG with jigs', 'stick welding with simple fixtures'],
  ['Coat', 'regional hot-dip galvaniser', 'cold-zinc + paint, shorter life, inspect at 5 yr'],
  ['Helix forming', 'hydraulic press and die', 'forge / cut-and-twist plate on a former'],
  ['Anchor drive', 'mini-excavator with drive head', 'portable hydraulic or electric drive, 3-6 kN.m [A]']])
sub('5.3', 'Quality control and acceptance')
table(['Where', 'Check', 'Accept', 'Frequency'], [
  ['Factory', 'segment length, bore, bolt pattern', 'tolerances in 2.9', '100%'],
  ['Factory', 'weld visual; magnetic particle', 'no cracks / undercut', '100% / 10%'],
  ['Factory', 'coating thickness', '>= 85 um mean, no bare spots', 'every batch'],
  ['Site', 'anchor installation torque and depth', '>= class torque, depth >= 12 helix dia', '100%, logged'],
  ['Site', 'anchor proof load', '1.2 x Qreq or local code, no creep', '2 per site minimum [A]'],
  ['Site', 'ring level, chords, bolt torque', 'tolerances 2.9; tagged', '100%'],
  ['Record', 'tamper-evident install log (append-only)', 'no tag = no occupancy', 'per unit']])
sub('5.4', 'Production time model [A]')
tt = [('P1 segment + node block', 0.80), ('P2 anchor', 0.50), ('P3 skirt fin', 0.20), ('P4 hardware set', 0.05)]
table(['Part', 'Touch h each', 'Qty R-12', 'Touch h per kit'], [[a, f'{b:.2f}', '12', f'{12*b:.1f}'] for a, b in tt])
kit_h = sum(12*b for _, b in tt)
P('')
para(f'One R-12 kit = {kit_h:.1f} touch hours. A 2-person cell on one 8 h shift makes about {16/kit_h:.2f} kits, roughly {16/kit_h*230:.0f} kits per year (230 shifts); '
     f'a 4-person cell about {32/kit_h*230:.0f}. Galvanising is outsourced and not counted.')
sub('5.5', 'Site installation procedure (R-12, 3-person crew)')
table(['Step', 'Action', 'Checkpoint', 'Hours'], [
  ['0', 'site gate sign-off (geotech, water table, class)', 'documents filed before mobilising', '-'],
  ['1', 'set out centre + 12 nodes, level compacted gravel pad', 'radius +/-10 mm', '1.0'],
  ['2', 'drive 12 anchors, log torque and depth, tag', 'torque >= 2.6 kN.m each; refusal = stop', '4.0'],
  ['3-4', 'seat segments on sleeves, bolt, shim, close and torque ring', 'level +/-3 mm per 2 m', '2.0'],
  ['5', 'bolt skirt fins, backfill in 200 mm lifts, plate test', 'compaction, verticality', '1.0'],
  ['6', 'erect shell (shell module, not counted)', 'hip shoes seat without force', '-'],
  ['', 'TOTAL foundation', f'loadable immediately (no cure)', f'{ref["t_install_h"]:.1f}']])

# =============================================================== 6. MATERIALS
sec(6, 'MATERIALS SPECIFICATION')
sub('6.1', 'Bill of materials, R-12, T1')
sk = sc['skirts_kg']/12
tblock('BOM T1', ['Part', 'Specification', 'Qty', 'kg each', 'kg total'], [
  ['P1 ring segment', 'recycled RHS 150x100x6 x 2.0 m + node block', '12', f'{ref["seg_kg"]:.1f}', f'{sc["segments_kg"]:.0f}'],
  ['P2 anchor A1', '60 kN class, >= 3.0 m, 2 helices D200, galvanised', '12', '20.0', f'{sc["anchors_kg"]:.0f}'],
  ['P3 skirt fin', f'4 mm sheet 2000 x {ref["skirt"]:.2f} m', '12', f'{sk:.1f}', f'{sc["skirts_kg"]:.0f}'],
  ['P4 hardware', 'M20 8.8 sets, shims, tags', '12', '5.0', f'{sc["hardware_kg"]:.0f}'],
  ['TOTAL', '', '', '', f'{sc["total_kg"]:.0f}']],
  note='Shell BOM is the shell module: ~117 m2 of facets at the tier areal mass (3.4); out of scope of this foundation-first run.')
sub('6.2', 'Sustainability documentation (indicative [A5])')
table(['Item', 'Cast raft', 'Kit, recycled steel', 'Kit, virgin steel'], [
  ['Mass', f'{gr["mass_t"]:.1f} t concrete', f'{sc["total_kg"]/1000:.2f} t steel', f'{sc["total_kg"]/1000:.2f} t steel'],
  ['Embodied CO2e', f'{gr["co2_t"]:.2f} t', f'{gv["kit_co2_recycled"]:.2f} t', f'{gv["kit_co2_virgin"]:.2f} t'],
  ['Ratio to raft', '100%', f'{100*gv["co2_ratio_recycled"]:.0f}%', f'{100*gv["co2_ratio_virgin"]:.0f}%'],
  ['Ground left behind', 'concrete mass', 'nothing after extraction', 'nothing after extraction'],
  ['Time to full load', '~10 days [A]', 'immediate', 'immediate']])
P('')
para('Carbon-negative is NOT claimed: it holds only for the wider displacement accounting of the programme, which this run cannot verify. '
     'Require recycled-steel content and EPDs: the steel source moves the result about as much as the design change itself (1.1 vs 3.6 t against a 5.8 t raft).')
sub('6.3', 'Sourcing options')
table(['Setting', 'Steel', 'Anchors', 'Note'], [
  ['Industrial region', 'scrap-based RHS, local galvaniser', 'screw-anchor makers (generic helix)', 'qualify by test, not brand'],
  ['Rural / low-capital', 'welded box from scrap plate and angle', 'pipe + plate helices, local press', 'proof-test each batch; de-rate class'],
  ['Remote / island', 'containerised kit from regional node', 'same', f'~10 kits per 20 ft container [A]']])
P('')
para('Substitution rule: any box section with Mp >= 36 kN.m, wall >= 6 mm and the 3.3 bolt pattern qualifies as P1; any anchor passing the '
     'torque-capacity test to its class qualifies as P2. Specify performance, never brand.')
sub('6.4', 'End-of-life pathways')
table(['Material', 'Pathway', 'Recovery target [A]'], [
  ['P1/P3 steel', 'unbolt; inspect and re-use, else scrap', '>= 60% re-used, rest recycled'],
  ['P2 anchors', 'reverse-torque extraction; cut and leave only if stuck', '>= 90% of foundation mass (gate V8)'],
  ['P4 hardware', 'sort and re-use or recycle', '>= 80%'],
  ['Gravel / backfill', 'leave or re-use on site', '100% inert'],
  ['Shell T1', 'ferrocement crushed as aggregate; timber re-used', 'tier dependent'],
  ['Shell T2/T3', 'manufacturer take-back and re-pulp / re-process', 'tier dependent, unverified']])

# =============================================================== 7. LIFECYCLE
sec(7, 'LIFECYCLE DOCUMENTATION')
sub('7.1', 'User manual outline')
for l in ['• What the unit is and is not: design wind class label (never "proof"); occupancy rules; evacuation guidance',
          '• Record pack: torque log, as-built levels, class label plate, inspection ports, spare-boss locations',
          '• Do-not list: no excavation within 1.5 m of the ring; no drilling or cutting of hip ribs; no overhangs or lean-tos on the shell',
          '• After any event: gust >= 80% of class, flood, earthquake, excavation nearby -> inspect before reuse']: PW(l)
sub('7.2', 'Maintenance schedule')
table(['Interval', 'Task', 'Who'], [
  ['Annual', 'visual: ring, nodes, bolts, skirt exposure, drainage, berm', 'owner'],
  ['5 years', 'torque re-check 10% of bolts; level survey; sleeve inspection', 'trained technician'],
  ['10 years', 'excavate one node to inspect coating and anchor head; recoat if needed', 'technician'],
  ['Event driven', 'full node and level inspection; replace deformed parts', 'technician + engineer']])
sub('7.3', 'Repair and upgrade paths')
for l in ['• Segment or node block: unbolt, replace 1:1 (tier-agnostic interface).',
          '• Anchor: unscrew and replace, or add a second anchor through the spare boss on N100+ blocks.',
          '• Wind-class upgrade WC2 -> WC4: bolt on skirt extension strips; swap anchors up one class.',
          '• Tier upgrade: swap shell facets (T1 -> T2), then ring segments 1:1 (T2 -> T3); foundation never re-dug.',
          '• Coating repair: wire-brush, cold zinc, record in the log.']: PW(l)
sub('7.4', 'End-of-life disassembly')
for l in ['1. Strip shell facets by tier. 2. Remove skirt fins and backfill. 3. Unbolt ring segments. 4. Reverse-torque each anchor, log depth.',
          '5. Sort steel; re-use or recycle. 6. Reinstate ground; no concrete remains.']: PW(l)

# =============================================================== 8. SCALE PLANNING
sec(8, 'SCALE PLANNING')
sub('8.1', 'Prototype programme')
table(['Stage', 'Tests / build', 'Closes gate'], [
  ['P0 bench', 'anchor pull-out/torque in 2 soils; node proof to 1.5 x class; segment bending; skirt lateral cyclic', 'V2, V3 (part)'],
  ['P0 wind', '1:25 wind-tunnel models: 45 deg cone-on-knee vs dome, tornado-like vortex if available; CFD cross-check', 'V1'],
  ['P1 unit', 'instrumented R-12: anchors, ring strain, level; install-time study', 'V3, V4 start'],
  ['P2 pilot', '10 units over 3 ground types incl. one extraction at 12 months', 'V6, V8']])
sub('8.2', 'Small batch to mass production')
table(['Level', 'Units / yr', 'Fabrication', 'Install'], [
  ['Pilot', '10-50', '1 workshop, 2-person cell, jigs', '1 crew'],
  ['Series', '500-2,000', f'3 nodes x 4-person cells (~{32/kit_h*230:.0f} kits/yr each)', '10 crews, trained'],
  ['Mass', '10,000+', 'regional nodes, outsourced galvanising, kit packing', 'franchised crews + audit']])
sub('8.3', 'Distribution model')
para('Open drawings and the performance classes (3.3, 3.4) are the product; fabrication is local-first. Kits ship by container (~10 R-12 per 20 ft [A]). '
     'Each region certifies against its own code route; install logs are append-only so audit does not depend on any one vendor.')

# =============================================================== 9. VERIFICATION REPORT
sec(9, 'OPTIBEST VERIFICATION REPORT')
sub('9.1', 'Studies conducted')
table(['#', 'Study', 'Finding'], [
  ['S1', 'Code basis', 'ASCE 7-22 Ch.32 adds tornado loads for Risk Cat III/IV (~EF2 or less); ICC 500/FEMA P-361 shelters: 250 mph, 15 lb 2x4 at 100 mph walls / 67 mph roof, GCpi +/-0.55'],
  ['S2', 'Shape, equal function', 'pure steep cone dominated; cone-on-knee 45 deg wins most weight space; dome rival; flips with aero inputs'],
  ['S3', 'Foundation types', 'raft 34 t vs kit 1.9 t; precast-rib systems patented; shell footings: evidence mixed; spun-cast unsuited to shells'],
  ['S4', 'Anchor method', 'Qult = Kt x T; published Kt 23-33 1/m (tension lower); AC358 depth >= 12 helix dia; torque = built-in QA'],
  ['S5', 'Model validation', 'cone vs drum ratios 0.50 / 0.33 match closed form; Cf 0.5-0.6 per code round-structure tables'],
  ['S6', 'Uncertainty', '20,000 draws; anchor utilisation P95 0.59, P(>1) = 0.000; shape choice assumption-sensitive'],
  ['S7', 'Below / above ground', 'flotation limit 1.5 m; berm to knee: base shear 48%, moment 75%'],
  ['S8', 'Prior art', 'radial-rib precast foundation patent families; helical basics old; FTO gate V5'],
  ['S9', 'Dome tornado evidence', 'vendor-sourced anecdotes (concrete domes surviving strong tornadoes); not independent; not relied on']])
sub('9.2', 'Seven dimensions: evidence and status')
table(['Dimension', 'Evidence', 'Status'], [
  ['Functional', f'R-12 WC4: anchor util P50 {res["mc"]["util"][1]:.2f}; skirt {ref["skirt"]:.2f} m; flotation rule', 'concept met; V1-V3'],
  ['Efficiency', f'steel {100*gv["mass_ratio"]:.1f}% of raft mass; CO2e {100*gv["co2_ratio_recycled"]:.0f}-{100*gv["co2_ratio_virgin"]:.0f}%; S/Au {knee["S_per_Au"]:.2f} vs {pure["S_per_Au"]:.2f}', 'met (indicative)'],
  ['Robustness', f'capacity design; anchors {60/ref["Qreq"]:.1f}x demand; failure order 3.2', 'concept; V3 connections'],
  ['Scalability', 'n = 8..48, one segment, anchors A1-A3', 'foundation met; shell n >= 24 needs analysis'],
  ['Maintainability', 'bolted, inspection ports, spare boss, replaceable skirt', 'met'],
  ['Innovation', 'integration: constant-chord ring + torque-as-QA + demountable skirt; parts are known', 'partial, honestly'],
  ['Elegance', '4 foundation part families (P1-P4), 1 tooling set, 1 segment section', 'met']])
sub('9.3', 'Iteration history with enhancement deltas')
nm = {0: 'cast gravity raft + cone', 1: 'ring + screw anchors', 2: 'constant-chord segment', 3: 'skirt fin carries sliding', 4: 'anchor classes, x1.2 built in'}
rows = [[l['it'], nm[l['it']], f'{l["mass_t"]:.2f}', f'{l["co2_t"]:.2f}', l['tooling'], l['steps'], f'{l["days_to_load"]:.1f}', f'{l["margin"]:.2f}', l['demount_pct']] for l in res['ledger']]
table(['It', 'Change', 'Mass t', 'CO2e t', 'Tooling', 'Steps', 'Days', 'Margin', 'Demount %'], rows)
P('')
gi = res['geometry_iter']; p6, k4 = gi['pure60'], gi['knee45']
table(['It 5: shell geometry', 'M kN.m', 'Hold-down kN', 'S/Au', 'H m'],
      [['pure 60 deg cone', f'{p6["M"]:.0f}', f'{p6["HD"]:.0f}', f'{p6["S_per_Au"]:.2f}', f'{p6["H"]:.1f}'],
       ['45 deg on 2.1 m knee', f'{k4["M"]:.0f}', f'{k4["HD"]:.0f}', f'{k4["S_per_Au"]:.2f}', f'{k4["H"]:.1f}'],
       ['delta', f'{100*(k4["M"]/p6["M"]-1):+.0f}%', f'{100*(k4["HD"]/p6["HD"]-1):+.0f}%', f'{100*(k4["S_per_Au"]/p6["S_per_Au"]-1):+.0f}%', f'{100*(k4["H"]/p6["H"]-1):+.0f}%']])
P('')
para('Definitions: Tooling = distinct formwork/jig sets for the 6-size ladder. Steps = field operations. Days = to full design load '
     '(raft: 3 d work + 7 d to 70% strength [A]). Margin = installed class capacity / demand (>1 = reserve). Demount % = recoverable by mass [A, gate V8]. '
     'I1, I2, I4 are measured on R-12 at WC4; I3 is design logic (it avoids extra anchors for sliding) and changes none of these metrics.')
sub('9.4', 'Plateau verification (five methods)')
P('Method 1  Multi-attempt enhancement seeking (7 attempts; threshold 10% = model noise floor)')
P('')
verd = {'alpha 40': 'inside noise; suction data thin; not adopted', 'alpha 50': 'worse on every metric', 'chord 1.5m': 'worse: more steel, more time',
        'hub + n/2': 'worse: more steel, no gain (weak-soil option only)', '2 anchors': 'worse: more steel/time; demand already under A1',
        'lighter shell': 'tier-driven trade-off: demand up, material down', 'APC-vented': 'CONDITIONAL vector: needs ICC 500 vent area, rated vents'}
rows = []
for a in res['attempts'][1:]:
    v = next(t for k_, t in verd.items() if a['label'].startswith(k_))
    pc = lambda x: '0%' if abs(x) < 0.5 else f'{x:+.0f}%'
    rows.append([a['label'][:28], pc(a['d_HD']), pc(a['d_steel']), pc(a['d_t']), pc(a['d_H']), v])
table(['Attempt', 'd Hold-down', 'd Steel', 'd Install', 'd Height', 'Verdict'], rows)
P('')
para('Result PASS (scoped): no unconditional gain above 10%. Anti-gaming: the first pass DID find a real gap (pure cone dominated), so the second-angle '
     'analysis (dome comparison, 12-case assumption flip, Monte Carlo) was run before claiming a plateau.')
P('')
P('Method 2  Independent perspectives')
P('')
table(['Perspective', 'Finding', 'Mitigation / status'], [
  ['User', 'tall interior volume; framed openings in facets', 'knee wall gives full floor; rated opening frames; usability test at P1'],
  ['Manufacturer', 'galvaniser access, helix forming', 'local alternatives 5.2; qualify by test'],
  ['Maintainer', 'buried anchors hard to inspect', 'sleeve ports; excavate 1 node / 10 yr; replaceable parts'],
  ['Adversary', 'skipped torque log, short anchors, "tornado-proof" marketing', 'no tag = no occupancy; class labels; 2% audit; append-only log'],
  ['Planet', 'virgin steel erodes the carbon case', 'require recycled content + EPDs; no cement in ground']])
P('')
para('Result CONDITIONAL: every weakness has a procedure, none is field-proven yet.')
P('')
P('Method 3  Alternative architectures')
P('')
table(['Architecture', 'Measured / known', 'Verdict'], [
  ['A cast raft + cone (baseline)', f'{gr["mass_t"]:.0f} t, {gr["co2_t"]:.1f} t CO2e, ~10 d to load, not demountable', 'baseline'],
  ['B precast radial-rib (turbine-style)', 'heavy concrete, crane, active patent families', 'rejected: weight, patents'],
  ['C dome on AEQUBASE', 'lower moment; double-curved fabrication', 'equivalent; alt shell; same kit'],
  ['D anchors only, no ring', 'no continuous tie, no skirt, no levelling datum', 'rejected: path discontinuity'],
  ['E earthbag dome + ballast', 'cheapest, heavy; WC1-WC2; slow build', 'equivalent for low-class, low-tech'],
  ['F conical shell footing', 'lab results disagree (+15% load vs ~half Ngamma)', 'rejected as baseline; option for gravity sites']])
P('')
para('Result PASS: AEQUBASE is superior or equal with less complexity for WC2-WC4; (E) is the honest low-tech equal at WC1.')
P('')
P('Method 4  Theoretical limit analysis (R-12, WC4)')
P('')
zp_req = ref['Mseg']*1e6/(0.9*275)/1e3
table(['Parameter', 'Minimum', 'Installed', 'Gap explanation'], [
  ['Anchor steel', f'~{12*ref["Qreq"]/3.0:.0f} kg (3 kN/kg)', f'{sc["anchors_kg"]:.0f} kg', 'practical minimum class + 1 anchor per node (robustness): immutable'],
  ['Skirt steel', f'{sc["skirts_kg"]:.0f} kg (passive demand)', f'{sc["skirts_kg"]:.0f} kg', 'equals minimum for this soil; 48% of steel: vector V-2'],
  ['Segment Zp', f'{zp_req:.0f} cm3', '143 cm3', 'handling, bolting, torsion, corrosion: partly immutable; T2/T3 lighter'],
  ['Install time', '~2 h (12 drives)', f'{ref["t_install_h"]:.0f} h', 'set-out, QA, backfill: mechanisation can trim'],
  ['Cone Cf', '0.25-0.35 (dome-like)', '0.6 assumed', 'unverified: gate V1']])
P('')
para('Result PASS: all gaps explained as immutable or logged as vectors.')
P('')
P('Method 5  Fresh perspective')
P('')
para('Re-read as a stranger: the brief asked for an optimal framework starting from foundations. The answer separates invariants from conditionals, '
     'corrects the pure-cone intuition with numbers, and gives a kit that is one segment, one node, a few anchor classes. It is the best this evidence supports; '
     'it is not proven optimal, and V1 can still flip the shell. Result PASS with that qualification.')
sub('9.5', 'Uncertainty')
mc = res['mc']
table(['Quantity (R-12 WC4)', 'P5', 'P50', 'P95'], [
  ['Base shear kN', f'{mc["F"][0]:.0f}', f'{mc["F"][1]:.0f}', f'{mc["F"][2]:.0f}'],
  ['Moment kN.m', f'{mc["M"][0]:.0f}', f'{mc["M"][1]:.0f}', f'{mc["M"][2]:.0f}'],
  ['Breach uplift kN', f'{mc["U"][0]:.0f}', f'{mc["U"][1]:.0f}', f'{mc["U"][2]:.0f}'],
  ['Anchor tension per node kN', f'{mc["Tmax"][0]:.1f}', f'{mc["Tmax"][1]:.1f}', f'{mc["Tmax"][2]:.1f}'],
  ['Anchor utilisation (class A1)', f'{mc["util"][0]:.2f}', f'{mc["util"][1]:.2f}', f'{mc["util"][2]:.2f}']])
P('')
para('Sampled: exposure B/C/D, Cf 0.5-0.8, cone lift 0.05-0.5, shell mass +/-15%, true Kt 15-33 1/m, GCpi 0.18 or 0.55. The uplift spread (about +/-50%) is why '
     'differences below 10% are not claimed as enhancements.')
sub('9.6', 'Open verification gates')
table(['Gate', 'What closes it', 'Pass criterion'], [
  ['V1', 'wind tunnel / CFD, incl. vortex loading: Cf, lift, peak local Cp', 'CL(ext) <= 0.5 and Cf <= 0.8, else default shell becomes dome'],
  ['V2', 'site geotech + anchor load tests (AC358-style)', 'measured Kt >= 23 1/m, else de-rate class'],
  ['V3', 'shell + node structural analysis and tests; envelope tests if shelter claimed', 'node proof >= 1.5 x class; buckling OK'],
  ['V4', 'soil corrosivity and coating life data', '50-yr life by corrosivity class'],
  ['V5', 'patent freedom-to-operate review (attorney)', 'no blocking claims, or design-around'],
  ['V6', 'seismic and liquefaction site gate', 'site class accepted'],
  ['V7', 'flood, groundwater, berm drainage', 'flotation margin >= 1.1'],
  ['V8', 'extraction and re-use trials', '>= 90% by mass recoverable'],
  ['V9', 'independent peer review + licensed structural engineer; local code route', 'signed off per jurisdiction']])
sub('9.7', 'Known limitations and enhancement vectors')
for l in ['• Sectional drag model: no vortex shedding, no tornado translation/vertical flow, no dynamic response. Shell buckling and ovalling not analysed.',
          '• Soil generic; cost, labour and times are estimates [A]; EFE "renewable" only partly met by a metal foundation.',
          '• Shape ranking depends on assumed lift coefficients: dome wins if the cone is aerodynamically pessimistic.',
          '• T2/T3 are performance targets, unverified.',
          '• V-1 APC-vented lantern: in the model GCpi 0.18 removes net hold-down; needs ICC 500 vent area and debris-rated vents.',
          '• V-2 lighter skirt: battered anchors or partial-height skirt. V-3 composite ring (T2) for mass. V-4 hub-and-spoke only for weak soils.',
          '• V-5 fewer, larger nodes at n >= 36. V-6 optional berm module with drainage design.']: PW(l)
sub('9.8', 'Prior art and patent register (not legal advice; gate V5)')
for l in ['• Precast radial-rib / pedestal-section foundations for wind turbines are in granted families, examples US10876269, US10934679, US10968592, US11795653, US10724204, EP3845712A1 (status and claims not verified here). AEQUBASE avoids integral ribs and concrete-specific claims.',
          '• Screw anchors are old art; manufacturer-specific helix profiles may be patented: specify generic plate helices.',
          '• Conical shell footings are academic literature; spun-cast pole splices carry patents (e.g. US5285614). Neither is used.']: PW(l)
sub('9.9', 'Sources consulted')
for l in ['• ASCE 7-22 Chapter 32 tornado loads: gaf.com building-science blog on ASCE 7-22 tornado loads; enr.com/articles/53126-tornado-resistant-building-design-premieres-in-asce-7-22',
          '• Safe room criteria: flash.org/mitigation/install-a-safe-room; icfmag.com 2023/08 why ICF safe rooms provide the best protection; FEMA P-361 / ICC 500 summaries',
          '• ICC 500 pressure coefficients and peer review: structuremag.org nssaicc-500-2014-storm-shelter-standard-structural-provisions and structural-design-and-coordination-of-icc-500-tornado-shelters',
          '• Shell footings: ijert.org experimental-study-on-conical-shell-footing; Geotechnique, flat vs conical circular foundations on sand (emerald.com jgeot 58/10/781); koreascience.or.kr JAKO201432252667540',
          '• Helical torque correlation: geoengineer.org history-of-torque-correlation-kt-factor; commercial.supportworks.com helical piles design examples; hubbell origin of the Kt factor',
          '• Conical roof pressures: grain-bin wind-tunnel study (academia.edu 19420957); CFD of a conical-roofed low-rise building (researchgate 356774855); structville.com how-to-apply-wind-load-on-roofs; round-structure Cf: engineersedge wind-loading-chimney',
          '• Patents: patents.google.com US10876269, US10934679; dome survivability claims: monolithic.org (vendor source); spun concrete: dorner.at betonblog']: PW(l)
sub('9.10', 'Reproduce')
block('COMMANDS', ['$ python3 aequcone_model.py      # regenerates results.json (seeded)', '$ python3 draw_sheets.py          # regenerates the drawing set',
                   '$ python3 build_odf.py            # regenerates this document from results.json'], wrap=False)

# =============================================================== 10. CERTIFICATION
sec(10, 'CERTIFICATION (SCOPED)')
block('EFE OPTIBEST ENGINEERING CERTIFICATION - SCOPED', [
  'Design      : AEQUCONE v0.1 / AEQUBASE foundation kit',
  'Purpose     : one parametric, scale-invariant, tier-agnostic axisymmetric shell framework on a mass-producible demountable ring foundation',
  'Scale       : Global framework; household-community units (n = 8..48)',
  'Iterations  : 5 design iterations after baseline, 7 plateau attempts, 12-case assumption flip, 20,000-draw Monte Carlo',
  '',
  'EFE FILTER  : Sustainable PASS(cond) | Renewable PARTIAL | Accessible PASS(cond) | Open PASS(cond, V5) | Local-first PASS | Circular PASS(target)',
  '              Durable CONDITIONAL (V4)',
  'DIMENSIONS  : Functional met(concept) | Efficiency met(indicative) | Robustness concept | Scalability met(foundation)',
  '              Maintainability met | Innovation partial | Elegance met',
  'PLATEAU     : M1 PASS | M2 CONDITIONAL | M3 PASS | M4 PASS | M5 PASS (qualified)',
  'OPEN GATES  : V1 wind, V2 geotech/anchor tests, V3 structure, V4 durability, V5 patents, V6 seismic, V7 flood, V8 EOL, V9 peer review',
  'DELIVERABLES: 9-section package, 3-sheet drawing set, reproducible model',
  '',
  'STATUS: ◈ CONCEPT PLATEAU (CONDITIONAL). NOT STRUCTURALLY CERTIFIED. The PREMIUM stamp is withheld until V1-V3 close.',
  'If any gate fails, the plateau claim for the affected element is withdrawn and this document is revised.'], 'double', wrap=True)

# =============================================================== APPENDIX A
P(''); sgl(); P('APPENDIX A: CALCULATION BASIS (CHECKABLE BY HAND)'); sgl(); P('')
V = 111.76; H_ = ref['H']; Kz_ = 2.01*(H_/274.32)**(2/9.5); q_ = 0.613*Kz_*V**2
Ap_ = math.pi*(ref['D']/2)**2; CL_ = 0.25
block('FORMULAS', [
  'q(z)   = 0.613 Kz V^2   Kz = 2.01 (max(z,4.57)/274.32)^(2/9.5)   [N/m2, V in m/s]',
  'F, M   = integral q Cf w dz ;  integral q Cf w z dz         (w = silhouette width at height z)',
  'U      = q(H) (CL + GCpi) pi R^2        Ws = sigma g S        P = 0.9 (Ws + Wring) - U',
  'T/node = max(0, (2M/R - P)/n)           Qreq = 1.2 T          torque = Qreq / Kt',
  'skirt  : 0.5 gamma Kp d^2 (2R) 0.5 = F   ->  d = sqrt(2F / (gamma Kp 2R 0.5))',
  'Mseg   = T L / 8        ring thrust  T_ring = w R^2 / (2 sin(alpha))',
  'raft   : W >= (U + max(M/Rf, F/mu)) / 0.9'], wrap=False)
P('')
table(['R-12, WC4 step', 'Value'], [
  ['H (circumscribed cone)', f'{H_:.2f} m'], ['Kz(H)', f'{Kz_:.3f}'], ['q(H)', f'{q_:.0f} Pa'],
  ['F, M (integrated)', f'{ref["F"]:.0f} kN, {ref["M"]:.0f} kN.m'],
  ['U = q (0.25+0.55) pi R^2', f'{q_*(CL_+0.55)*Ap_/1000:.0f} kN (matches model {ref["U"]:.0f})'],
  ['Ws (200 kg/m2)', f'{ref["Ws"]:.0f} kN'], ['P', f'{ref["P"]:.0f} kN (negative = net uplift)'],
  ['T per node', f'{ref["Tmax"]:.1f} kN'], ['Qreq = 1.2 T', f'{ref["Qreq"]:.1f} kN -> A1 60 kN'], ['torque', f'{ref["torque"]:.2f} kN.m'],
  ['skirt d', f'{ref["skirt"]:.2f} m'], ['Mseg', f'{ref["Mseg"]:.1f} kN.m']])

# =============================================================== APPENDIX B
P(''); sgl(); P('APPENDIX B: VISUAL PROMPTS (T1 / T2 / T3)'); sgl(); P('')
P('T1 PROTO'); P('')
para('Documentary photograph of a twelve-sided conical-roof shelter, 7.7 m across, 45-degree roof of twelve flat ferrocement facets over a 2.1 m knee wall, '
     'standing on a ring of galvanised recycled-steel box-section segments with bolted node blocks at twelve points, skirt-fin trench half backfilled; two workers '
     'drive a screw anchor with a portable hydraulic head beside a torque-log tablet; dry savanna at golden hour, long shadows; Canon EOS R5, 24-70mm f/2.8 at 35mm, '
     'f/8, 1/250 s, ISO 100, 5600 K, polariser, tripod at 1.4 m, low three-quarter angle, ring in foreground on the lower third, Kodak Portra 400 emulation, 3:2, 300 DPI, TIFF.')
P(''); P('T2 ADVANCED'); P('')
para('Architectural photograph of the same twelve-facet shelter in basalt-fibre composite: dark basalt-grey ring segments with exposed M20 bolt patterns, '
     'BFRP and hemp sandwich facets in a matte natural-fibre finish, vented apex lantern, coastal dunes under soft overcast light; Sony A7R V, 24mm tilt-shift at f/11, '
     '1/125 s, ISO 64, 6000 K, graduated ND filter, tripod, level horizon, symmetrical frontal composition on the door facet, Fujifilm Pro 400H emulation, 4:5, 300 DPI, TIFF.')
P(''); P('T3 APEX'); P('')
para('Restrained futuristic photograph of the twelve-facet shelter at blue hour: CNT-polymer composite ring and facets with a faint diamond-coating sheen on the node '
     'blocks, warm interior light through a single rated opening, glassy wet ground reflecting the roof lines; Hasselblad X2D 100C, XCD 45mm f/4 at f/9, 1/60 s, ISO 64, '
     '4500 K, tripod, low centred angle, 1:1 crop, soft vignette, 300 DPI, TIFF.')

P(''); dbl(); P('                                  END OF DOCUMENT'); P('                    AEQUCONE v0.1 │ AEQUBASE │ 2026-10-10 │ CONCEPT PLATEAU (CONDITIONAL)'); dbl()

txt = '\n'.join(out) + '\n'
bad = [(i+1, len(l)) for i, l in enumerate(out) if len(l) > W]
open('AEQUCONE_blueprint.odf.txt', 'w').write(txt)
print('lines', len(out), 'over-width', bad[:10]); print('block over', OVER[:15])
