#!/usr/bin/env python3
"""AEQUCONE drawing set v0.1 — drawn from results.json (same numbers as the ODF blueprint). SCHEMATIC, NOT FOR CONSTRUCTION."""
import json, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle, Rectangle, Ellipse
from matplotlib.backends.backend_pdf import PdfPages

res = json.load(open('results.json')); ref = res['ref']
BG, LN, AC, DM, HT, GR = '#0b2a4a', '#d7ecff', '#ffd166', '#7fc8f8', '#164b7a', '#6f93b8'
plt.rcParams.update({'font.family': 'DejaVu Sans Mono', 'text.color': LN, 'savefig.facecolor': BG, 'figure.facecolor': BG})

N, L = 12, 2.0
Rc = L/(2*math.sin(math.pi/N)); Ap = Rc*math.cos(math.pi/N)          # circumradius, apothem
KNEE, FFL = 2.1, 0.15
Hk = FFL + KNEE; Htop = Hk + Ap*math.tan(math.radians(45))
SK = ref['skirt']; DATE = '2026-10-10'

def axes(fig, rect, title, equal=True):
    ax = fig.add_axes(rect); ax.set_facecolor(BG)
    if equal: ax.set_aspect('equal', adjustable='box')
    ax.set_xticks([]); ax.set_yticks([]); [s.set_visible(False) for s in ax.spines.values()]
    ax.set_title(title, color=AC, fontsize=9.5, loc='left', pad=6); return ax
def ln(ax, xs, ys, c=LN, lw=1.2, ls='-', z=3): ax.plot(xs, ys, color=c, lw=lw, ls=ls, zorder=z, solid_capstyle='round')
def dh(ax, x1, x2, y, t, c=DM, dy=0.14, fs=7):
    ax.annotate('', xy=(x1, y), xytext=(x2, y), arrowprops=dict(arrowstyle='<->', color=c, lw=0.9, shrinkA=0, shrinkB=0))
    ax.text((x1+x2)/2, y+dy, t, ha='center', va='bottom', color=c, fontsize=fs)
def dv(ax, x, y1, y2, t, c=DM, dx=0.15, fs=7):
    ax.annotate('', xy=(x, y1), xytext=(x, y2), arrowprops=dict(arrowstyle='<->', color=c, lw=0.9, shrinkA=0, shrinkB=0))
    ax.text(x+dx, (y1+y2)/2, t, ha='left', va='center', color=c, fontsize=fs)
def ground(ax, x1, x2, d):
    ax.add_patch(Rectangle((x1, -d), x2-x1, d, fill=False, hatch='////', edgecolor=GR, lw=0, zorder=1, alpha=.55))
    ln(ax, [x1, x2], [0, 0], lw=1.6)
def txt(ax, x, y, s, c=LN, fs=6.8, ha='left', va='center', **k): ax.text(x, y, s, color=c, fontsize=fs, ha=ha, va=va, **k)
def titleblock(fig, sheet, title):
    ax = fig.add_axes([0.665, 0.012, 0.325, 0.085]); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=LN, lw=1.2))
    ax.text(0.02, 0.78, 'AEQUCONE v0.1  |  axisymmetric shell + AEQUBASE foundation kit', fontsize=8.2, color=AC, va='center')
    ax.text(0.02, 0.50, f'SHEET {sheet}/3  {title}', fontsize=7.6, va='center')
    ax.text(0.02, 0.24, f'{DATE}  |  dims m  |  CONCEPT STAGE - SCHEMATIC - NOT FOR CONSTRUCTION', fontsize=6.6, color=DM, va='center')

NODE_TH = [math.radians(15 + 30*k) for k in range(N)]               # node angles (door facet centred at -90 deg)
NODE_TH = [t - math.radians(90) for t in NODE_TH]                    # N1 at -75 deg
NODES = [(Rc*math.cos(t), Rc*math.sin(t)) for t in NODE_TH]

# ===================================================================== SHEET 1
def sheet1():
    fig = plt.figure(figsize=(16.5, 11.7)); fig.text(0.015, 0.965, 'REFERENCE UNIT R-12  |  D 7.73 m  |  45 deg conical roof on 2.1 m knee wall  |  WC4 foundation',
                                                    fontsize=12, color=AC, weight='bold')
    # ---- elevation
    ax = axes(fig, [0.015, 0.47, 0.485, 0.46], 'ELEVATION (view on facet S12 - door)')
    ground(ax, -6, 6, 3.3)
    ax.add_patch(Rectangle((-Ap, 0), 2*Ap, FFL, fc=HT, ec=LN, lw=1.0, zorder=4))
    sx, sy = [-Ap, -Ap, 0, Ap, Ap], [FFL, Hk, Htop, Hk, FFL]
    ax.add_patch(Polygon(list(zip(sx, sy)), closed=True, fc=HT, ec='none', alpha=.35, zorder=2)); ln(ax, sx, sy, lw=1.8)
    xs = [Rc*math.sin(math.radians(a)) for a in (15, 45, 75)]
    for x in xs + [-v for v in xs]:
        ln(ax, [x, x], [FFL, Hk], lw=.8); ln(ax, [x, 0], [Hk, Htop], lw=.6)
    ln(ax, [-Ap, Ap], [Hk, Hk], lw=.9)
    ax.add_patch(Rectangle((-.5, FFL), 1.0, 2.0, fc=BG, ec=AC, lw=1.2, zorder=5)); txt(ax, 0, FFL+1.0, 'DOOR\n1.0x2.0', AC, 6, 'center', zorder=6)
    ax.add_patch(Rectangle((-Ap, -SK), 2*Ap, SK, fill=False, ec=DM, ls='--', lw=.9, zorder=3)); txt(ax, -Ap+.1, -SK/2, f'SKIRT FIN {SK:.2f} m (hidden)', DM, 6.2)
    for x in xs + [-v for v in xs]:
        ln(ax, [x, x], [0, -3.0], c=DM, ls='--', lw=.8)
        for yy in (-2.2, -2.8): ax.add_patch(Ellipse((x, yy), .24, .05, fill=False, ec=DM, lw=.8))
    txt(ax, 3.9, -3.05, 'ANCHORS (hidden)', DM, 6.2)
    dh(ax, -Ap, Ap, -3.75, f'{2*Ap:.2f} across flats  |  {2*Rc:.2f} across nodes')
    dv(ax, Ap+.7, 0, Htop, f'{Htop:.2f} apex above grade'); dv(ax, Ap+1.9, FFL, Hk, f'{KNEE:.2f} knee wall', fs=6.6)
    txt(ax, -3.6, 5.0, 'roof 45 deg', AC, 7.5)
    txt(ax, -6.2, 6.55, 'Facets: flat panels (12 wall + 12 roof). Hip ribs land on nodes.', LN, 6.4)
    ax.set_xlim(-6.6, 10.0); ax.set_ylim(-4.4, 7.0)
    # ---- section
    ax = axes(fig, [0.505, 0.47, 0.485, 0.46], 'SECTION A-A  (through opposite nodes N1-N7, hip line)')
    ground(ax, -6, 6, 3.6)
    for s in (-1, 1):
        ax.add_patch(Polygon([(s*Rc, FFL), (s*Rc, Hk), (0, Htop), (0, Htop-.12), (s*(Rc-.12), Hk-.1), (s*(Rc-.12), FFL)],
                             closed=True, fc=HT, ec=LN, lw=1.1, hatch='////', zorder=3))
        ax.add_patch(Rectangle((s*Rc-.05, 0), .10, FFL, fc=BG, ec=AC, lw=1.1, zorder=5))                        # ring RHS
        ax.add_patch(Rectangle((s*Rc-.13, FFL), .26, .03, fc=AC, ec='none', zorder=5))                          # node plate
        ln(ax, [s*Rc, s*Rc], [0, -SK], c=AC, lw=2.2); ln(ax, [s*Rc, s*Rc], [-SK, -3.0], c=DM, lw=2.0)             # skirt, anchor
        for yy in (-2.2, -2.8): ax.add_patch(Ellipse((s*Rc, yy), .5, .1, fc=BG, ec=DM, lw=1.0, zorder=4))
    ln(ax, [-Rc+.1, Rc-.1], [FFL, FFL], c=LN, lw=1.3); ax.add_patch(Rectangle((-Rc+.1, -.15), 2*Rc-.2, .30, fill=False, hatch='...', edgecolor=GR, lw=0, zorder=2))
    ax.add_patch(Rectangle((-1.65, -2.45), 3.3, 2.6, fill=False, ec=DM, ls='--', lw=1.0, zorder=3))
    txt(ax, 0, -1.2, 'OPTIONAL CORE CELL  D3.0 x 2.4\nonly if water table >= 1.5 m\nbelow FFL (else flotation anchors)', DM, 6.4, 'center')
    txt(ax, 0, Htop+.35, 'APEX CAP: compression ring / vent lantern option', LN, 6.4, 'center')
    txt(ax, -Rc-.2, -SK/2, f'SKIRT FIN\n4 mm x {SK:.2f} m', AC, 6.2, 'right'); txt(ax, -Rc-.2, -2.5, 'ANCHOR A1 (60 kN)\n>=3.0 m, 2 helices D200', DM, 6.2, 'right')
    txt(ax, Rc+.2, .08, 'RING: RHS 150x100x6 + node block', AC, 6.2)
    dv(ax, -Rc+.7, FFL, FFL+2.1, '2.10 m clear', fs=6.6); txt(ax, 0, 1.0, 'LIVING VOLUME', LN, 7, 'center')
    dh(ax, -Rc, Rc, -3.95, f'{2*Rc:.2f} node circle D')
    ax.set_xlim(-9.0, 9.2); ax.set_ylim(-4.6, 7.0)
    # ---- plan
    ax = axes(fig, [0.015, 0.02, 0.30, 0.44], 'PLAN AT FFL  (ring, nodes, anchors, hips)')
    pts = NODES + [NODES[0]]
    ax.add_patch(Polygon(NODES, closed=True, fc=HT, ec='none', alpha=.3)); ln(ax, [p[0] for p in pts], [p[1] for p in pts], lw=2.4)
    ax.add_patch(Circle((0, 0), Rc, fill=False, ec=GR, ls=':', lw=.8))
    for i, (x, y) in enumerate(NODES):
        ln(ax, [x, 0], [y, 0], c=GR, lw=.6)
        ax.add_patch(Circle((x, y), .17, fc=BG, ec=AC, lw=1.2, zorder=5)); ln(ax, [x-.17, x+.17], [y, y], c=AC, lw=.8, z=6); ln(ax, [x, x], [y-.17, y+.17], c=AC, lw=.8, z=6)
        k = 1.17; txt(ax, x*k, y*k, f'N{i+1}', AC, 6.6, 'center', zorder=7)
    inner = [(x*.965, y*.965) for x, y in NODES]; ax.add_patch(Polygon(inner, closed=True, fill=False, ec=DM, ls='--', lw=.9))
    ax.add_patch(Rectangle((-.5, -Ap-.05), 1.0, .1, fc=BG, ec=AC, lw=1.2, zorder=6)); txt(ax, 0, -Ap-.62, 'S12 DOOR', AC, 6.5, 'center')
    for a in range(0, 360, 45):
        r0, r1 = 6.7, 5.3; ax.annotate('', xy=(r1*math.cos(math.radians(a)), r1*math.sin(math.radians(a))), xytext=(r0*math.cos(math.radians(a)), r0*math.sin(math.radians(a))),
                                       arrowprops=dict(arrowstyle='->', color=AC, lw=1.0))
    txt(ax, 0, 0, 'APEX', LN, 6, 'center'); txt(ax, 0, -1.2, f'floor {math.pi*Rc**2*0+ (N/4)*L**2/math.tan(math.pi/N):.1f} m2\n(polygon)', LN, 6.4, 'center')
    dh(ax, -Ap, Ap, 5.0, f'{2*Ap:.2f} across flats'); txt(ax, 0, 7.55, 'WIND FROM ANY BEARING -> SAME LOAD PATH (rotational symmetry)', AC, 6.8, 'center')
    ax.set_xlim(-7.4, 7.4); ax.set_ylim(-7.4, 8.0)
    # ---- notes
    ax = fig.add_axes([0.33, 0.115, 0.655, 0.335]); ax.axis('off'); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=GR, lw=.8))
    notes = ['NOTES (concept stage; every [A] item is a verification gate - see ODF section 9)',
      '1. Foundation = ring of 12 identical segments (chord 2.000 m) + 12 screw anchors + continuous skirt fin. Shell sits on it by 12 hip shoes.',
      f'2. Design basis WC4: 250 mph 3-s gust, ICC 500 GCpi +/-0.55 (breach case). Demand per node: T = {ref["Tmax"]:.1f} kN uplift; required Qult = {ref["Qreq"]:.1f} kN -> class A1 (60 kN).',
      f'3. Install torque target {ref["torque"]:.1f} kN.m (Qult/Kt, Kt = 23 1/m [A]); log every anchor; reject below target. Min embed >= 12 helix dia.',
      f'4. Skirt depth {SK:.2f} m from passive resistance in dense granular soil (phi 32, gamma 18) [A]. Replace with site geotech values.',
      '5. Loads on circumscribed circular frustum (conservative wind area). Shell areal mass 200 kg/m2 [A]. Aero Cf 0.6, CL(ext) 0.25 [A] -> wind tunnel / CFD gate V1.',
      '6. Shelter claims require tested envelope (15 lb 2x4 @ 100 mph walls / 67 mph roof), peer review and a licensed engineer. This sheet is not that.',
      '7. Floor at FFL = +0.15 above grade. Ring bears on compacted gravel. Berm up to knee height halves base shear (see ODF 2.6).']
    for i, s in enumerate(notes): ax.text(.012, .92-i*.118, s, fontsize=7.6, color=AC if i == 0 else LN, va='center')
    titleblock(fig, 1, 'REFERENCE UNIT R-12 - ELEVATION / SECTION / PLAN'); return fig

# ===================================================================== SHEET 2
def sheet2():
    fig = plt.figure(figsize=(16.5, 11.7)); fig.text(0.015, 0.965, 'AEQUBASE FOUNDATION KIT  |  one segment, one node, six sizes', fontsize=12, color=AC, weight='bold')
    # ---- node plan
    ax = axes(fig, [0.015, 0.50, 0.34, 0.43], 'NODE DETAIL - PLAN (mm, schematic)')
    for sgn, ang in ((-1, math.radians(15)), (1, math.radians(-15))):
        d = np.array([sgn*math.cos(ang if sgn > 0 else -ang) if False else 0, 0])
    A = np.array([-math.cos(math.radians(15)), -math.sin(math.radians(15))]); B = np.array([math.cos(math.radians(15)), -math.sin(math.radians(15))])
    for v in (A, B):
        n = np.array([-v[1], v[0]]); p0 = v*130; p1 = v*900
        ax.add_patch(Polygon([p0+n*50, p1+n*50, p1-n*50, p0-n*50], closed=True, fc=HT, ec=LN, lw=1.1))
        ln(ax, [(v*150)[0], (v*900)[0]], [(v*150)[1]-0, (v*900)[1]], c=GR, ls='--', lw=.6)
    ax.add_patch(Rectangle((-130, -130), 260, 260, fc=BG, ec=AC, lw=1.6, zorder=5)); ax.add_patch(Circle((0, 0), 35, fc=BG, ec=DM, lw=1.2, zorder=6))
    for bx, by in ((-90, 90), (90, 90), (-90, -90), (90, -90)): ax.add_patch(Circle((bx, by), 12, fc=AC, ec='none', zorder=6))
    ax.add_patch(Rectangle((-60, 130), 120, 80, fc=BG, ec=DM, ls='--', lw=1.0, zorder=5))
    txt(ax, 0, 250, 'HIP SHOE (shell module)', DM, 6.4, 'center'); txt(ax, 0, -250, 'NODE BLOCK 260x260  |  4xM20 per segment end\nANCHOR SLEEVE D70  |  ring turns 30 deg per node', AC, 6.4, 'center')
    txt(ax, -880, 120, 'SEG A\nRHS 150x100x6', LN, 6.4); txt(ax, 880, 120, 'SEG B', LN, 6.4, 'right')
    ax.set_xlim(-1000, 1000); ax.set_ylim(-450, 400)
    # ---- node section
    ax = axes(fig, [0.36, 0.50, 0.13, 0.43], 'NODE SECTION')
    ax.add_patch(Rectangle((-130, 0), 260, 150, fc=HT, ec=AC, lw=1.4)); ax.add_patch(Rectangle((-30, -300), 60, 300, fc=BG, ec=DM, lw=1.2))
    ground(ax, -500, 500, 1250); ax.set_ylim(-1300, 400)
    ln(ax, [0, 0], [-300, -900], c=DM, lw=3); txt(ax, 60, -600, 'ANCHOR SHAFT', DM, 6.2)
    ln(ax, [-12, 12, -12, 12], [-950, -980, -1010, -1040], c=GR, lw=1)   # break
    for yy in (-1130, -1230): ax.add_patch(Ellipse((0, yy), 200, 40, fc=BG, ec=DM, lw=1.1))
    ln(ax, [-250, -250], [0, -900], c=AC, lw=3); ln(ax, [250, 250], [0, -900], c=AC, lw=3); txt(ax, -260, -450, 'SKIRT\nFIN', AC, 6.2, 'right')
    txt(ax, 0, 230, 'NODE BLOCK', AC, 6.6, 'center'); txt(ax, 280, -1180, 'HELICES x2', DM, 6.2); ax.set_xlim(-520, 620)
    # ---- parts schedule
    ax = fig.add_axes([0.50, 0.50, 0.485, 0.43]); ax.axis('off'); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=GR, lw=.8)); sc = res['steel_comp']
    skirt_each = sc['skirts_kg']/12
    rows = [('P1', 'RING SEGMENT', 'RHS 150x100x6 x 2.000 chord + node block', 12, ref['seg_kg']),
            ('P2', 'SCREW ANCHOR A1', '60 kN class, >=3.0 m, 2 helices D200', 12, 20.0),
            ('P3', 'SKIRT FIN', f'4 mm x 2.000 x {SK:.2f} m (trim to wind class)', 12, skirt_each),
            ('P4', 'HARDWARE SET', 'M20 bolts, shims, torque tags', 12, 5.0),
            ('P5', 'HIP SHOE', 'shell interface (shell module BOM)', 12, 0.0),
            ('P6', 'ANCHOR CLASSES', 'A1 60 | A2 100 | A3 150 | A4 250 kN ...', 0, 0.0)]
    ax.text(.015, .93, 'PARTS SCHEDULE - REFERENCE UNIT R-12 (same P1/P4 family for every size)', fontsize=8.2, color=AC, va='center')
    ax.text(.015, .83, 'NO   PART               SPEC                                         QTY    kg ea   kg tot', fontsize=7, color=DM, va='center')
    for i, (a, b, c, q, m) in enumerate(rows):
        y = .73-i*.1; ax.text(.015, y, f'{a:3s}  {b:17s} {c:44s} {q:3d}  {m:7.1f}  {q*m:7.1f}', fontsize=7, va='center')
    ax.text(.015, .12, f'TOTAL FOUNDATION STEEL {sc["total_kg"]/1000:.2f} t   |   gravity raft equivalent {res["gravity_ref"]["mass_t"]:.1f} t concrete   |   steel is {100*res["gravity_vs_kit"]["mass_ratio"]:.1f}% of raft mass',
            fontsize=7.4, color=AC, va='center')
    # ---- assembly sequence
    steps = [('1 SET OUT', 'mark 12 nodes, level pad', '1 h'), ('2 DRIVE ANCHORS', 'log torque >= 2.6 kN.m', '4 h'), ('3 SET SEGMENTS', 'seat on sleeves', '1 h'),
             ('4 CLOSE + TORQUE RING', 'bolt up, check level', '1 h'), ('5 FIT SKIRT + BACKFILL', 'compact in lifts', '1 h'), ('6 ERECT SHELL', 'hips onto shoes (shell module)', '-')]
    for i, (h, s, t) in enumerate(steps):
        ax = axes(fig, [0.015+i*0.1645, 0.255, 0.155, 0.20], f'{h}', True); ax.title.set_fontsize(7.4)
        pts = NODES + [NODES[0]]; ax.set_xlim(-5.2, 5.2); ax.set_ylim(-5.4, 5.4)
        if i >= 0:
            for x, y in NODES: ln(ax, [x-.15, x+.15], [y, y], c=GR, lw=.8); ln(ax, [x, x], [y-.15, y+.15], c=GR, lw=.8)
        if i >= 1:
            for x, y in NODES: ax.add_patch(Circle((x, y), .22, fc=DM, ec='none'))
        if i >= 2:
            for k in range(N if i >= 3 else 6): ln(ax, [NODES[k][0], NODES[(k+1) % N][0]], [NODES[k][1], NODES[(k+1) % N][1]], lw=3, c=LN)
        if i >= 4: ax.add_patch(Polygon([(x*.93, y*.93) for x, y in NODES], closed=True, fill=False, ec=AC, ls='--', lw=1.2))
        if i >= 5:
            for x, y in NODES: ln(ax, [x, 0], [y, 0], c=LN, lw=.7)
            ax.add_patch(Polygon(NODES, closed=True, fc=HT, ec='none', alpha=.5))
        ax.text(0, -5.15, f'{s}  [{t}]', fontsize=6.4, color=DM, ha='center', va='center')
    # ---- size ladder
    ax = axes(fig, [0.015, 0.02, 0.28, 0.215], 'SIZE LADDER - same segment, n = 8 ... 48 (nested, to scale)')
    cols = ['#7fc8f8', '#a9dcff', '#ffd166', '#ffb86b', '#ff9b9b', '#d7ecff']
    for (n, c) in zip((8, 12, 16, 24, 36, 48), cols):
        r = L/(2*math.sin(math.pi/n)); th = [2*math.pi*k/n for k in range(n+1)]
        ln(ax, [r*math.cos(t) for t in th], [r*math.sin(t) for t in th], c=c, lw=1.1)
    ax.set_xlim(-28, 17); ax.set_ylim(-16.5, 16.5)
    for (n, c, yy) in zip((8, 12, 16, 24, 36, 48), cols, np.linspace(14, -14, 6)):
        r = L/(2*math.sin(math.pi/n)); txt(ax, -27.5, yy, f'n={n:2d}  D={2*r:5.1f} m', c, 6.8)
    # ---- size table (WC4)
    ax = fig.add_axes([0.30, 0.02, 0.365, 0.215]); ax.axis('off'); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=GR, lw=.8))
    ax.text(.015, .92, 'FOUNDATION SELECTION CHART (WC4 = 250 mph, breach case; shell 200 kg/m2 [A])', fontsize=7.3, color=AC, va='center')
    ax.text(.015, .80, ' n    D(m)  H(m)  floor  T(kN)  Qreq  anchor  skirt  steel(t)  install(h)', fontsize=6.8, color=DM, va='center')
    k4 = [k for k in res['kit_table'] if k['wc'] == 'WC4']
    for i, k in enumerate(k4):
        ax.text(.015, .68-i*.105, f'{k["n"]:2d}   {k["D"]:5.1f} {k["H"]:5.1f} {k["Afloor"]:6.0f}  {k["Tmax"]:5.1f} {k["Qreq"]:5.1f}   A{[60,100,150,250,400,650].index(k["anchor_Q"])+1} {k["anchor_Q"]:3d}  {k["skirt"]:5.2f}  {k["steel_t"]:6.2f}   {k["t_install_h"]:5.0f}',
                fontsize=6.8, va='center')
    ax.text(.015, .075, 'n>=24 use a truncated vented lantern (tau 0.3-0.6) to cap height.', fontsize=6.3, color=DM, va='center'); ax.text(.015, .020, 'All sizes: ONE segment section (Mseg <= 19 kN.m vs 35 kN.m design cap).', fontsize=6.3, color=DM, va='center')
    titleblock(fig, 2, 'AEQUBASE KIT-OF-PARTS / ASSEMBLY / SIZES'); return fig

# ===================================================================== SHEET 3
def sheet3():
    fig = plt.figure(figsize=(16.5, 11.7)); fig.text(0.015, 0.965, 'STUDY EVIDENCE  |  numbers behind the shape and foundation decisions (reproducible: aequcone_model.py)', fontsize=12, color=AC, weight='bold')
    def styl(ax):
        ax.set_facecolor(BG); [ax.spines[s].set_color(LN) for s in ax.spines]; ax.tick_params(colors=LN, labelsize=7); ax.title.set_color(AC); ax.title.set_fontsize(9)
        ax.xaxis.label.set_color(LN); ax.yaxis.label.set_color(LN); ax.grid(color=GR, alpha=.25, lw=.5)
    # (a) shapes
    ax = fig.add_axes([0.05, 0.56, 0.42, 0.34]); styl(ax); sh = res['shape_table']; x = np.arange(len(sh)); w = .38
    ax.bar(x-w/2, [s['M'] for s in sh], w, color=DM, label='wind overturning M (kN.m)'); ax.bar(x+w/2, [s['HD'] for s in sh], w, color=AC, label='hold-down demand (kN)')
    ax.set_xticks(x); ax.set_xticklabels([s['name'].replace(' ', '\n', 1) for s in sh], fontsize=6.3); ax.legend(facecolor=BG, edgecolor=GR, labelcolor=LN, fontsize=7)
    ax.set_title('A  SHAPES AT EQUAL USABLE FLOOR (40 m2), 250 mph, breach case')
    # (b) cone sweep: hold-down demand vs roof angle, by knee-wall height
    ax = fig.add_axes([0.55, 0.56, 0.42, 0.34]); styl(ax); sw = res['cone_sweep']
    for hk, c in zip((0.0, 0.9, 1.5, 2.1), (GR, DM, '#ffb86b', AC)):
        pts = [(q['alpha'], q['HD']) for q in sw if q['hk'] == hk]; ax.plot(*zip(*pts), color=c, lw=1.8, marker='o', ms=3.5, label=f'knee wall {hk} m')
    ax.axvspan(40, 50, color=AC, alpha=.12); ax.set_xlabel('roof angle (deg)'); ax.set_ylabel('hold-down demand (kN) at 40 m2 usable')
    m45 = [q['M'] for q in sw if q['alpha'] == 45 and q['hk'] == 2.1][0]; m60 = [q['M'] for q in sw if q['alpha'] == 60 and q['hk'] == 0.0][0]
    ax.text(41, ax.get_ylim()[1]*.93, f'nominal 45 deg / 2.1 m knee: M = {m45:.0f} kN.m\npure 60 deg cone: M = {m60:.0f} kN.m', fontsize=7, va='top')
    ax.legend(facecolor=BG, edgecolor=GR, labelcolor=LN, fontsize=7, loc='upper right'); ax.set_title('B  CONE FAMILY: knee wall cuts hold-down; steep cones cost moment')
    # (c) raft vs kit
    ax = fig.add_axes([0.05, 0.16, 0.28, 0.30]); styl(ax); g = res['gravity_vs_kit']
    lab = ['mass (t)', 'CO2e (t)']; ax.bar([0-.27, 1-.27], [g['raft_mass_t'], g['raft_co2']], .26, color=GR, label='cast gravity raft')
    ax.bar([0, 1], [g['kit_steel_t'], g['kit_co2_recycled']], .26, color=AC, label='kit, recycled steel'); ax.bar([0+.27, 1+.27], [g['kit_steel_t'], g['kit_co2_virgin']], .26, color=DM, label='kit, virgin steel')
    ax.set_xticks([0, 1]); ax.set_xticklabels(lab); ax.set_yscale('log'); ax.legend(facecolor=BG, edgecolor=GR, labelcolor=LN, fontsize=7)
    for xx, v in ((-.27, g['raft_mass_t']), (0, g['kit_steel_t']), (.27, g['kit_steel_t']), (1-.27, g['raft_co2']), (1, g['kit_co2_recycled']), (1+.27, g['kit_co2_virgin'])): ax.text(xx, v*1.12, f'{v:.1f}', ha='center', fontsize=7)
    ax.set_title('C  FOUNDATION: raft vs ring + anchors (R-12, WC4)\nCO2e factors indicative [A]')
    # (d) MC
    h = res['mc_hist']; ax = fig.add_axes([0.38, 0.16, 0.27, 0.30]); styl(ax); e = np.array(h['util_edges']); ax.bar(e[:-1], h['util_counts'], width=np.diff(e), align='edge', color=DM, edgecolor=BG)
    ax.axvline(1.0, color='#ff7b7b', lw=1.5); ax.set_xlabel('anchor utilisation (demand / capacity)'); ax.set_ylabel('count of 20,000 draws')
    ax.set_title(f'D  MONTE CARLO (aero, soil, mass, exposure)\nP5/P50/P95 = {res["mc"]["util"][0]:.2f}/{res["mc"]["util"][1]:.2f}/{res["mc"]["util"][2]:.2f}; P(util>1) = {res["mc"]["p_util_gt1"]:.3f}')
    # (e) flotation
    ax = fig.add_axes([0.72, 0.16, 0.25, 0.30]); styl(ax); fl = res['flotation']
    ax.plot([f['water_depth'] for f in fl], [f['margin'] if f['margin'] else 3 for f in fl], color=AC, marker='o', lw=1.8); ax.axhline(1.1, color='#ff7b7b', lw=1.2, ls='--')
    ax.set_xlabel('water table depth below FFL (m)'); ax.set_ylabel('weight / buoyancy'); ax.set_title('E  SUB-GRADE CORE CELL flotation (D3.0 x 2.4)\nred = 1.1 minimum margin')
    titleblock(fig, 3, 'STUDY EVIDENCE'); return fig

if __name__ == '__main__':
    figs = [sheet1(), sheet2(), sheet3()]
    with PdfPages('AEQUCONE_drawing_set.pdf') as pdf:
        for i, f in enumerate(figs, 1):
            f.savefig(f'sheet{i}.png', dpi=70); pdf.savefig(f)
    print('drawn')
